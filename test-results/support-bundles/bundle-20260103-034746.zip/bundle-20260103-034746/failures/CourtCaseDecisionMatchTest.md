# Failure Brief: CourtCaseDecisionMatchTest

**Component:** `focused:CourtCaseDecisionMatchTest`
**Generated:** 2026-01-03T03:46:46+00:00
**Consecutive Failures:** 5

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh CourtCaseDecisionMatchTest
```

---

## Failing Tests

- Tests\Unit\Models\CourtCaseDecisionMatchTest > co

---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Models/CourtCaseDecisionMatchTest.php:35
tests/Unit/Models/CourtCaseDecisionMatchTest.php:58
tests/Unit/Models/CourtCaseDecisionMatchTest.php:91
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Models/CourtCaseDecisionMatchTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh CourtCaseDecisionMatchTest`
2. **View full log:** `less test-logs/CourtCaseDecisionMatchTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component CourtCaseDecisionMatchTest`

