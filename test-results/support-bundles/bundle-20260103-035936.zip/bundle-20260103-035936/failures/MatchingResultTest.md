# Failure Brief: MatchingResultTest

**Component:** `focused:MatchingResultTest`
**Generated:** 2026-01-03T03:58:47+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh MatchingResultTest
```

---

## Failing Tests

- Tests\Unit\DTOs\MatchingResultTest > matching

---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/DTOs/MatchingResultTest.php:12
tests/Unit/DTOs/MatchingResultTest.php:29
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/DTOs/MatchingResultTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh MatchingResultTest`
2. **View full log:** `less test-logs/MatchingResultTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component MatchingResultTest`

