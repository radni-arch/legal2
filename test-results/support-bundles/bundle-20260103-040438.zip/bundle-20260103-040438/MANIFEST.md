# Support Bundle: bundle-20260103-040438

**Generated:** 2026-01-03T04:04:41+00:00
**Reason:** Consecutive failures threshold exceeded: focused:CaseDecisionMatchingServiceTest
**Branch:** claude/refactor-court-warrant-system-kCdls
**Commit:** 96c0842

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/CaseDecisionMatchingServiceTest.md
failures/CourtCaseDecisionMatchTest.md
failures/MatchingResultTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
96c0842 feat: add MatchingResult DTO
afcad32 feat: add caseMatches relationship to CourtDecision
494e414 feat: add decision matching relationships to CourtCase
8528395 feat: add CourtCaseDecisionMatch model with tests
3dd5af7 feat: add court_case_decision_matches migration
```
