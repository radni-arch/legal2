# Failure Brief: CaseDecisionMatchingServiceTest

**Component:** `focused:CaseDecisionMatchingServiceTest`
**Generated:** 2026-01-03T04:08:59+00:00
**Consecutive Failures:** 3

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh CaseDecisionMatchingServiceTest
```

---

## Failing Tests

- Tests\Unit\Services\CaseDecisionMatchingServiceTest > matc

---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Services/CaseDecisionMatchingServiceTest.php:69
tests/Unit/Services/CaseDecisionMatchingServiceTest.php:92
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/CaseDecisionMatchingServiceTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh CaseDecisionMatchingServiceTest`
2. **View full log:** `less test-logs/CaseDecisionMatchingServiceTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component CaseDecisionMatchingServiceTest`

