# Failure Brief: CaseDecisionMatchingServiceTest

**Component:** `focused:CaseDecisionMatchingServiceTest`
**Generated:** 2026-01-03T04:15:40+00:00
**Consecutive Failures:** 6

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh CaseDecisionMatchingServiceTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```

```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh CaseDecisionMatchingServiceTest`
2. **View full log:** `less test-logs/CaseDecisionMatchingServiceTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component CaseDecisionMatchingServiceTest`

