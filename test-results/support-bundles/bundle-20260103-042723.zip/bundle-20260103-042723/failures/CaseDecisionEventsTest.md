# Failure Brief: CaseDecisionEventsTest

**Component:** `focused:CaseDecisionEventsTest`
**Generated:** 2026-01-03T04:26:42+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh CaseDecisionEventsTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Events/CaseDecisionEventsTest.php:17
tests/Unit/Events/CaseDecisionEventsTest.php:25
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Events/CaseDecisionEventsTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh CaseDecisionEventsTest`
2. **View full log:** `less test-logs/CaseDecisionEventsTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component CaseDecisionEventsTest`

