# Failure Brief: CaseDecisionEventsTest

**Component:** `focused:CaseDecisionEventsTest`
**Generated:** 2026-01-03T04:30:08+00:00
**Consecutive Failures:** 5

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh CaseDecisionEventsTest
```

---

## Failing Tests

- Tests\Unit\Events\CaseDecisionEventsTest > case

---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Events/CaseDecisionEventsTest.php:18
tests/Unit/Events/CaseDecisionEventsTest.php:26
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Events/CaseDecisionEventsTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh CaseDecisionEventsTest`
2. **View full log:** `less test-logs/CaseDecisionEventsTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component CaseDecisionEventsTest`

