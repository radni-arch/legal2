# Support Bundle: bundle-20260103-043651

**Generated:** 2026-01-03T04:36:54+00:00
**Reason:** Consecutive failures threshold exceeded: focused:MatchCaseToDecisionJobTest
**Branch:** claude/refactor-court-warrant-system-kCdls
**Commit:** b6a57bb

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingServiceTest.md
failures/CourtCaseDecisionMatchTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
b6a57bb feat: Add CaseDecisionMatched and CaseDecisionMatchVerified events
41e75a5 feat: add manual match and verification methods
7b7a8fa feat: add batch matching methods to service
341b29e feat: add matchCase method to CaseDecisionMatchingService
f178c72 feat: add CaseDecisionMatchingService with case number parsing
```
