# Failure Brief: MatchCaseToDecisionJobTest

**Component:** `focused:MatchCaseToDecisionJobTest`
**Generated:** 2026-01-03T04:35:59+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh MatchCaseToDecisionJobTest
```

---

## Failing Tests

- Tests\Unit\Jobs\MatchCaseToDecisionJobTest > job

---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Jobs/MatchCaseToDecisionJobTest.php:28
tests/Unit/Jobs/MatchCaseToDecisionJobTest.php:42
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Jobs/MatchCaseToDecisionJobTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh MatchCaseToDecisionJobTest`
2. **View full log:** `less test-logs/MatchCaseToDecisionJobTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component MatchCaseToDecisionJobTest`

