# Failure Brief: MatchCaseToDecisionJobTest

**Component:** `focused:MatchCaseToDecisionJobTest`
**Generated:** 2026-01-03T04:38:47+00:00
**Consecutive Failures:** 3

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh MatchCaseToDecisionJobTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```

```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh MatchCaseToDecisionJobTest`
2. **View full log:** `less test-logs/MatchCaseToDecisionJobTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component MatchCaseToDecisionJobTest`

