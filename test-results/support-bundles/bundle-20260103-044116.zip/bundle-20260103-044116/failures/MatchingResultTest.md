# Failure Brief: MatchingResultTest

**Component:** `focused:MatchingResultTest`
**Generated:** 2026-01-03T03:59:39+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh MatchingResultTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```

```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh MatchingResultTest`
2. **View full log:** `less test-logs/MatchingResultTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component MatchingResultTest`

