# Failure Brief: ReconcileUnmatchedCasesJobTest

**Component:** `focused:ReconcileUnmatchedCasesJobTest`
**Generated:** 2026-01-03T04:41:19+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ReconcileUnmatchedCasesJobTest
```

---

## Failing Tests

- Tests\Unit\Jobs\ReconcileUnmatchedCasesJobTest > job

---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Jobs/ReconcileUnmatchedCasesJobTest.php:27
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Jobs/ReconcileUnmatchedCasesJobTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ReconcileUnmatchedCasesJobTest`
2. **View full log:** `less test-logs/ReconcileUnmatchedCasesJobTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ReconcileUnmatchedCasesJobTest`

