# Failure Brief: MatchCaseDecisionsCommandTest

**Component:** `focused:MatchCaseDecisionsCommandTest`
**Generated:** 2026-01-03T04:46:05+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh MatchCaseDecisionsCommandTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Feature/Commands/MatchCaseDecisionsCommandTest.php:17
tests/Feature/Commands/MatchCaseDecisionsCommandTest.php:33
tests/Feature/Commands/MatchCaseDecisionsCommandTest.php:53
```

---

## Suspected Files

- `tests/Feature/Commands/MatchCaseDecisionsCommandTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh MatchCaseDecisionsCommandTest`
2. **View full log:** `less test-logs/MatchCaseDecisionsCommandTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component MatchCaseDecisionsCommandTest`

