# Failure Brief: UnmatchedCasesReportCommandTest

**Component:** `focused:UnmatchedCasesReportCommandTest`
**Generated:** 2026-01-03T04:50:47+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh UnmatchedCasesReportCommandTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Feature/Commands/UnmatchedCasesReportCommandTest.php:17
tests/Feature/Commands/UnmatchedCasesReportCommandTest.php:36
tests/Feature/Commands/UnmatchedCasesReportCommandTest.php:46
```

---

## Suspected Files

- `tests/Feature/Commands/UnmatchedCasesReportCommandTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh UnmatchedCasesReportCommandTest`
2. **View full log:** `less test-logs/UnmatchedCasesReportCommandTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component UnmatchedCasesReportCommandTest`

