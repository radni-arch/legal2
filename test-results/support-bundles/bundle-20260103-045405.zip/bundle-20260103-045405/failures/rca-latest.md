# RCA Draft: Repeated Failures

**Trigger:** 3 consecutive failures for `focused:UnmatchedCasesReportCommandTest`
**Generated:** 2026-01-03T04:52:35+00:00
**Threshold:** 3

---

## Summary

The component `focused:UnmatchedCasesReportCommandTest` has failed 3 times consecutively,
exceeding the RCA threshold of 3.

---

## Recent Failures (Last 5)

| Timestamp | Component | Outcome |
|-----------|-----------|---------|
| 2026-01-03T04:46:02+00:00 | `focused:MatchCaseDecisionsCommandTest` | fail |
| 2026-01-03T04:46:55+00:00 | `focused:MatchCaseDecisionsCommandTest` | fail |
| 2026-01-03T04:50:43+00:00 | `focused:UnmatchedCasesReportCommandTest` | fail |
| 2026-01-03T04:51:45+00:00 | `focused:UnmatchedCasesReportCommandTest` | fail |
| 2026-01-03T04:52:31+00:00 | `focused:UnmatchedCasesReportCommandTest` | fail |

---

## Failure Pattern Analysis

**Questions to investigate:**

1. [ ] Is this a new failure or regression?
2. [ ] Did recent code changes affect this component?
3. [ ] Are there external dependencies involved (DB, API, network)?
4. [ ] Is this a flaky test or deterministic failure?
5. [ ] Are other related components also failing?

---

## Recommended Actions

1. **Review the failure brief:**
   ```bash
   cat test-results/failures/UnmatchedCasesReportCommandTest.md
   ```

2. **Check recent commits:**
   ```bash
   git log --oneline -10
   ```

3. **Run with verbose output:**
   ```bash
   php artisan test --filter=UnmatchedCasesReportCommandTest -vvv
   ```

4. **Check environment:**
   ```bash
   /check-setup
   ```

---

## Resolution

_Fill in after investigation:_

**Root Cause:**

**Fix Applied:**

**Verification:**

