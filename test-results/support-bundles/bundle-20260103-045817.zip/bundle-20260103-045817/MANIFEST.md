# Support Bundle: bundle-20260103-045817

**Generated:** 2026-01-03T04:58:20+00:00
**Reason:** Consecutive failures threshold exceeded: focused:FetchPpPrzCasesIntegrationTest
**Branch:** claude/refactor-court-warrant-system-kCdls
**Commit:** 451d75f

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingServiceTest.md
failures/CourtCaseDecisionMatchTest.md
failures/FetchPpPrzCasesIntegrationTest.md
failures/MatchCaseDecisionsCommandTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/ReconcileUnmatchedCasesJobTest.md
failures/UnmatchedCasesReportCommandTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
451d75f feat: add cases:unmatched-report command
9c2ee9e feat: Add cases:match-decisions Artisan command
19119b9 feat: Add ReconcileUnmatchedCasesJob for scheduled case-decision matching
eece4bf feat: Add MatchCaseToDecisionJob for real-time case matching
b6a57bb feat: Add CaseDecisionMatched and CaseDecisionMatchVerified events
```
