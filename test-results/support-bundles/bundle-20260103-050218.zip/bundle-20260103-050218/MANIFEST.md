# Support Bundle: bundle-20260103-050218

**Generated:** 2026-01-03T05:02:21+00:00
**Reason:** Consecutive failures threshold exceeded: focused:CourtCaseDecisionMatch
**Branch:** claude/refactor-court-warrant-system-kCdls
**Commit:** 881fae1

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingServiceTest.md
failures/CourtCaseDecisionMatchTest.md
failures/FetchPpPrzCasesIntegrationTest.md
failures/MatchCaseDecisionsCommandTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/ReconcileUnmatchedCasesJobTest.md
failures/UnmatchedCasesReportCommandTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
881fae1 feat: schedule daily reconciliation job
0ee98eb feat: Dispatch MatchCaseToDecisionJob after case fetch
451d75f feat: add cases:unmatched-report command
9c2ee9e feat: Add cases:match-decisions Artisan command
19119b9 feat: Add ReconcileUnmatchedCasesJob for scheduled case-decision matching
```
