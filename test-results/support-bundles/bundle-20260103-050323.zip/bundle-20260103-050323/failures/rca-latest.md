# RCA Draft: Repeated Failures

**Trigger:** 3 consecutive failures for `focused:FetchPpPrzCasesIntegrationTest`
**Generated:** 2026-01-03T05:00:13+00:00
**Threshold:** 3

---

## Summary

The component `focused:FetchPpPrzCasesIntegrationTest` has failed 3 times consecutively,
exceeding the RCA threshold of 3.

---

## Recent Failures (Last 5)

| Timestamp | Component | Outcome |
|-----------|-----------|---------|
| 2026-01-03T04:54:26+00:00 | `focused:UnmatchedCasesReportCommandTest` | fail |
| 2026-01-03T04:54:48+00:00 | `focused:UnmatchedCasesReportCommandTest` | fail |
| 2026-01-03T04:57:20+00:00 | `focused:FetchPpPrzCasesIntegrationTest` | fail |
| 2026-01-03T04:58:16+00:00 | `focused:FetchPpPrzCasesIntegrationTest` | fail |
| 2026-01-03T05:00:09+00:00 | `focused:FetchPpPrzCasesIntegrationTest` | fail |

---

## Failure Pattern Analysis

**Questions to investigate:**

1. [ ] Is this a new failure or regression?
2. [ ] Did recent code changes affect this component?
3. [ ] Are there external dependencies involved (DB, API, network)?
4. [ ] Is this a flaky test or deterministic failure?
5. [ ] Are other related components also failing?

---

## Recommended Actions

1. **Review the failure brief:**
   ```bash
   cat test-results/failures/FetchPpPrzCasesIntegrationTest.md
   ```

2. **Check recent commits:**
   ```bash
   git log --oneline -10
   ```

3. **Run with verbose output:**
   ```bash
   php artisan test --filter=FetchPpPrzCasesIntegrationTest -vvv
   ```

4. **Check environment:**
   ```bash
   /check-setup
   ```

---

## Resolution

_Fill in after investigation:_

**Root Cause:**

**Fix Applied:**

**Verification:**

