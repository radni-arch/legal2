# Support Bundle: bundle-20260107-010522

**Generated:** 2026-01-07T01:05:25+00:00
**Reason:** Consecutive failures threshold exceeded: focused:CourtDecisionTagsUnicodeTest
**Branch:** claude/graph-enhancement-data-integrity-XqqqL
**Commit:** b8655b5

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/CaseDecisionEvents.md
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingService.md
failures/CaseDecisionMatchingServiceTest.md
failures/CourtCaseDecisionMatch.md
failures/CourtCaseDecisionMatchTest.md
failures/CourtDecisionTagsUnicodeTest.md
failures/FetchPpPrzCasesIntegrationTest.md
failures/GraphViewerTest.md
failures/MatchCaseDecisionsCommandTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/ReconcileUnmatchedCasesJobTest.md
failures/UnmatchedCasesReportCommandTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
b8655b5 Merge pull request #562 from aglavas/claude/fix-graph-viewer-roots-0iOb0
7de2d53 Merge branch 'master' into claude/fix-graph-viewer-roots-0iOb0
ccc48c5 Merge pull request #563 from aglavas/claude/fix-citation-modal-bth9G
6214aba Merge branch 'master' into claude/fix-citation-modal-bth9G
576416b Merge pull request #564 from aglavas/claude/document-llm-brain-Spsci
```
