# Failure Brief: CourtDecisionTagsUnicodeTest

**Component:** `focused:CourtDecisionTagsUnicodeTest`
**Generated:** 2026-01-07T01:02:14+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh CourtDecisionTagsUnicodeTest
```

---

## Failing Tests



---

## Error Messages

```
PHP Fatal error:  Uncaught Error: Failed opening required '/home/user/ai-legal-war-machine/vendor/autoload.php' (include_path='.:/usr/share/php') in /home/user/ai-legal-war-machine/artisan:10
```

---

## Stack Frames

```

```

---

## Suspected Files



---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh CourtDecisionTagsUnicodeTest`
2. **View full log:** `less test-logs/CourtDecisionTagsUnicodeTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component CourtDecisionTagsUnicodeTest`

