# Failure Brief: GraphConnectionExceptionTest

**Component:** `focused:GraphConnectionExceptionTest`
**Generated:** 2026-01-07T12:18:58+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphConnectionExceptionTest
```

---

## Failing Tests



---

## Error Messages

```
     15▕         $this->assertInstanceOf(GraphConnectionException::class, $exception);
  ➜  56▕         $exception = GraphConnectionException::forHost('neo4j://localhost:7687', $previous);
     58▕         $this->assertInstanceOf(GraphConnectionException::class, $exception);
  ➜  67▕         $exception = GraphConnectionException::forHost('bolt://remote:7687');
     69▕         $this->assertInstanceOf(GraphConnectionException::class, $exception);
  ➜  83▕         $exception = GraphConnectionException::forConnection($config, $previous);
     85▕         $this->assertInstanceOf(GraphConnectionException::class, $exception);
  ➜  98▕         $exception = GraphConnectionException::forConnection($config);
    100▕         $this->assertInstanceOf(GraphConnectionException::class, $exception);
  ➜ 108▕         $exception = GraphConnectionException::forHost('neo4j://production:7687');
```

---

## Stack Frames

```
tests/Unit/Exceptions/Graph/GraphConnectionExceptionTest.php:13
tests/Unit/Exceptions/Graph/GraphConnectionExceptionTest.php:22
tests/Unit/Exceptions/Graph/GraphConnectionExceptionTest.php:37
tests/Unit/Exceptions/Graph/GraphConnectionExceptionTest.php:47
tests/Unit/Exceptions/Graph/GraphConnectionExceptionTest.php:56
tests/Unit/Exceptions/Graph/GraphConnectionExceptionTest.php:67
tests/Unit/Exceptions/Graph/GraphConnectionExceptionTest.php:83
tests/Unit/Exceptions/Graph/GraphConnectionExceptionTest.php:98
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Exceptions/Graph/GraphConnectionExceptionTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphConnectionExceptionTest`
2. **View full log:** `less test-logs/GraphConnectionExceptionTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphConnectionExceptionTest`

