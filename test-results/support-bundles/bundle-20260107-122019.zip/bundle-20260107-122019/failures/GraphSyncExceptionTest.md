# Failure Brief: GraphSyncExceptionTest

**Component:** `focused:GraphSyncExceptionTest`
**Generated:** 2026-01-07T12:18:38+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphSyncExceptionTest
```

---

## Failing Tests

- Tests\Unit\Exceptions\Graph\GraphSyncExceptionTest > it

---

## Error Messages

```
     15▕         $this->assertInstanceOf(GraphSyncException::class, $exception);
  ➜  59▕         $exception = GraphSyncException::forNode('Judge', 123, $previous);
     61▕         $this->assertInstanceOf(GraphSyncException::class, $exception);
  ➜  72▕         $exception = GraphSyncException::forNode('Party', 456);
     74▕         $this->assertInstanceOf(GraphSyncException::class, $exception);
  ➜  84▕         $exception = GraphSyncException::forOperation('create', 'Decision', 789, $previous);
     86▕         $this->assertInstanceOf(GraphSyncException::class, $exception);
  ➜  99▕         $exception = GraphSyncException::forOperation('update', 'Citation', 321);
    101▕         $this->assertInstanceOf(GraphSyncException::class, $exception);
  ➜ 111▕         $exception = GraphSyncException::forNode('Judge', 123);
```

---

## Stack Frames

```
tests/Unit/Exceptions/Graph/GraphSyncExceptionTest.php:13
tests/Unit/Exceptions/Graph/GraphSyncExceptionTest.php:22
tests/Unit/Exceptions/Graph/GraphSyncExceptionTest.php:31
tests/Unit/Exceptions/Graph/GraphSyncExceptionTest.php:40
tests/Unit/Exceptions/Graph/GraphSyncExceptionTest.php:50
tests/Unit/Exceptions/Graph/GraphSyncExceptionTest.php:59
tests/Unit/Exceptions/Graph/GraphSyncExceptionTest.php:72
tests/Unit/Exceptions/Graph/GraphSyncExceptionTest.php:84
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Exceptions/Graph/GraphSyncExceptionTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphSyncExceptionTest`
2. **View full log:** `less test-logs/GraphSyncExceptionTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphSyncExceptionTest`

