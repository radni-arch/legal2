# Failure Brief: GraphConnectionExceptionTest

**Component:** `focused:GraphConnectionExceptionTest`
**Generated:** 2026-01-07T12:20:43+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphConnectionExceptionTest
```

---

## Failing Tests

- Tests\Unit\Exceptions\Graph\GraphConnectionExceptionTest > it

---

## Error Messages

```
    108▕         $exception = GraphConnectionException::forHost('neo4j://production:7687');
```

---

## Stack Frames

```
tests/Unit/Exceptions/Graph/GraphConnectionExceptionTest.php:111
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Exceptions/Graph/GraphConnectionExceptionTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphConnectionExceptionTest`
2. **View full log:** `less test-logs/GraphConnectionExceptionTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphConnectionExceptionTest`

