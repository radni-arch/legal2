# Failure Brief: EnhancedGraphSyncJobTest

**Component:** `focused:EnhancedGraphSyncJobTest`
**Generated:** 2026-01-07T19:15:05+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh EnhancedGraphSyncJobTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Jobs/EnhancedGraphSyncJobTest.php:34
tests/Unit/Jobs/EnhancedGraphSyncJobTest.php:54
tests/Unit/Jobs/EnhancedGraphSyncJobTest.php:77
tests/Unit/Jobs/EnhancedGraphSyncJobTest.php:97
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Jobs/EnhancedGraphSyncJobTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh EnhancedGraphSyncJobTest`
2. **View full log:** `less test-logs/EnhancedGraphSyncJobTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component EnhancedGraphSyncJobTest`

