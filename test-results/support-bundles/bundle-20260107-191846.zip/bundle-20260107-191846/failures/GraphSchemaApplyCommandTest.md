# Failure Brief: GraphSchemaApplyCommandTest

**Component:** `focused:GraphSchemaApplyCommandTest`
**Generated:** 2026-01-07T19:17:26+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphSchemaApplyCommandTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Console/Commands/GraphSchemaApplyCommandTest.php:108
tests/Unit/Console/Commands/GraphSchemaApplyCommandTest.php:123
tests/Unit/Console/Commands/GraphSchemaApplyCommandTest.php:23
tests/Unit/Console/Commands/GraphSchemaApplyCommandTest.php:45
tests/Unit/Console/Commands/GraphSchemaApplyCommandTest.php:67
tests/Unit/Console/Commands/GraphSchemaApplyCommandTest.php:88
```

---

## Suspected Files

- `tests/Unit/Console/Commands/GraphSchemaApplyCommandTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphSchemaApplyCommandTest`
2. **View full log:** `less test-logs/GraphSchemaApplyCommandTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphSchemaApplyCommandTest`

