# Support Bundle: bundle-20260107-214547

**Generated:** 2026-01-07T21:45:51+00:00
**Reason:** Consecutive failures threshold exceeded: focused:LegalConceptExtractorTest
**Branch:** claude/graph-enhancement-data-integrity-XqqqL
**Commit:** b3f0b3b

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/CaseDecisionEvents.md
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingService.md
failures/CaseDecisionMatchingServiceTest.md
failures/CourtCaseDecisionMatch.md
failures/CourtCaseDecisionMatchTest.md
failures/CourtDecisionOutcomeColumnsTest.md
failures/CourtDecisionTagsUnicodeTest.md
failures/DecisionGraphSyncServiceTest.md
failures/EnhancedGraphSyncJobTest.md
failures/FetchPpPrzCasesIntegrationTest.md
failures/GraphConnectionExceptionTest.md
failures/GraphDataIntegrityServiceTest.md
failures/GraphSchemaApplyCommandTest.md
failures/GraphSyncExceptionTest.md
failures/GraphViewerTest.md
failures/LegalPrincipleGraphSyncServiceTest.md
failures/LegalPrincipleGraphSyncServiceTest__it_reuses_existing_principle_node_for_same_pattern.md
failures/MatchCaseDecisionsCommandTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/ReconcileUnmatchedCasesJobTest.md
failures/UnmatchedCasesReportCommandTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
b3f0b3b chore: update orchestrator logs
c980a06 chore: update session logs
da96ee3 test: Add constraint violation and injection prevention tests (C.3, C.5)
cfa0882 test: Add end-to-end sync tests for PostgreSQL to Neo4j
3db25e8 Test: [Phase 2 - C.2] Add Cypher syntax validation tests
```
