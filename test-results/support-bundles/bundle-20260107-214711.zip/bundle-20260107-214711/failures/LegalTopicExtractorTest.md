# Failure Brief: LegalTopicExtractorTest

**Component:** `focused:LegalTopicExtractorTest`
**Generated:** 2026-01-07T21:46:01+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh LegalTopicExtractorTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Services/Graph/Extractors/LegalTopicExtractorTest.php:16
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/Extractors/LegalTopicExtractorTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh LegalTopicExtractorTest`
2. **View full log:** `less test-logs/LegalTopicExtractorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component LegalTopicExtractorTest`

