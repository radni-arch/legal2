# Failure Brief: LegalConceptExtractorTest

**Component:** `focused:LegalConceptExtractorTest`
**Generated:** 2026-01-07T21:48:17+00:00
**Consecutive Failures:** 3

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh LegalConceptExtractorTest
```

---

## Failing Tests



---

## Error Messages

```
  Failed asserting that an array contains 'Tužba'.
  Failed asserting that an array contains 'Kupoprodaja'.
  Failed asserting that an array contains 'Krađa'.
```

---

## Stack Frames

```
tests/Unit/Services/Graph/Extractors/LegalConceptExtractorTest.php:28
tests/Unit/Services/Graph/Extractors/LegalConceptExtractorTest.php:43
tests/Unit/Services/Graph/Extractors/LegalConceptExtractorTest.php:55
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/Extractors/LegalConceptExtractorTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh LegalConceptExtractorTest`
2. **View full log:** `less test-logs/LegalConceptExtractorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component LegalConceptExtractorTest`

