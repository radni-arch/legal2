# RCA Draft: Repeated Failures

**Trigger:** 3 consecutive failures for `focused:LegalTopicExtractorTest`
**Generated:** 2026-01-07T21:48:48+00:00
**Threshold:** 3

---

## Summary

The component `focused:LegalTopicExtractorTest` has failed 3 times consecutively,
exceeding the RCA threshold of 3.

---

## Recent Failures (Last 5)

| Timestamp | Component | Outcome |
|-----------|-----------|---------|
| 2026-01-07T21:47:10+00:00 | `focused:LegalTopicExtractorTest` | fail |
| 2026-01-07T21:47:20+00:00 | `focused:LegalConceptExtractorTest` | fail |
| 2026-01-07T21:48:11+00:00 | `focused:ArticleExtractorTest` | fail |
| 2026-01-07T21:48:14+00:00 | `focused:LegalConceptExtractorTest` | fail |
| 2026-01-07T21:48:44+00:00 | `focused:LegalTopicExtractorTest` | fail |

---

## Failure Pattern Analysis

**Questions to investigate:**

1. [ ] Is this a new failure or regression?
2. [ ] Did recent code changes affect this component?
3. [ ] Are there external dependencies involved (DB, API, network)?
4. [ ] Is this a flaky test or deterministic failure?
5. [ ] Are other related components also failing?

---

## Recommended Actions

1. **Review the failure brief:**
   ```bash
   cat test-results/failures/LegalTopicExtractorTest.md
   ```

2. **Check recent commits:**
   ```bash
   git log --oneline -10
   ```

3. **Run with verbose output:**
   ```bash
   php artisan test --filter=LegalTopicExtractorTest -vvv
   ```

4. **Check environment:**
   ```bash
   /check-setup
   ```

---

## Resolution

_Fill in after investigation:_

**Root Cause:**

**Fix Applied:**

**Verification:**

