# Failure Brief: ArticleExtractorTest

**Component:** `focused:ArticleExtractorTest`
**Generated:** 2026-01-07T21:48:15+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ArticleExtractorTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Services/Graph/Extractors/ArticleExtractorTest.php:16
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/Extractors/ArticleExtractorTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ArticleExtractorTest`
2. **View full log:** `less test-logs/ArticleExtractorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ArticleExtractorTest`

