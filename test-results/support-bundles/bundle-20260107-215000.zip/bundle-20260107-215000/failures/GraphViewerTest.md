# Failure Brief: GraphViewerTest

**Component:** `focused:GraphViewerTest`
**Generated:** 2026-01-06T14:40:08+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphViewerTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
/home/user/ai-legal-war-machine/tests/Feature/Livewire/VectorStoreManagerTest.php:571
```

---

## Suspected Files

- `tests/Feature/Livewire/VectorStoreManagerTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphViewerTest`
2. **View full log:** `less test-logs/GraphViewerTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphViewerTest`

