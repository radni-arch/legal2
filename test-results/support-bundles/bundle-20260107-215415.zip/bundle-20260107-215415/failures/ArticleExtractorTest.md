# Failure Brief: ArticleExtractorTest

**Component:** `focused:ArticleExtractorTest`
**Generated:** 2026-01-07T21:53:59+00:00
**Consecutive Failures:** 7

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ArticleExtractorTest
```

---

## Failing Tests

- Tests\Unit\Services\Graph\Extractors\ArticleExtractorTest > it

---

## Error Messages

```
  Failed asserting that an array is not empty.
  Failed asserting that actual size 1 matches expected size 3.
  Failed asserting that an array is not empty.
```

---

## Stack Frames

```
tests/Unit/Services/Graph/Extractors/ArticleExtractorTest.php:26
tests/Unit/Services/Graph/Extractors/ArticleExtractorTest.php:60
tests/Unit/Services/Graph/Extractors/ArticleExtractorTest.php:93
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/Extractors/ArticleExtractorTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ArticleExtractorTest`
2. **View full log:** `less test-logs/ArticleExtractorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ArticleExtractorTest`

