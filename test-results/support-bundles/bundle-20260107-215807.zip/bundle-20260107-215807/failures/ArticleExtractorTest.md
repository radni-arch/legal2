# Failure Brief: ArticleExtractorTest

**Component:** `focused:ArticleExtractorTest`
**Generated:** 2026-01-07T21:57:46+00:00
**Consecutive Failures:** 10

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ArticleExtractorTest
```

---

## Failing Tests

- Tests\Unit\Services\Graph\Extractors\ArticleExtractorTest > it

---

## Error Messages

```
  Failed asserting that actual size 5 matches expected size 3.
```

---

## Stack Frames

```
tests/Unit/Services/Graph/Extractors/ArticleExtractorTest.php:126
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/Extractors/ArticleExtractorTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ArticleExtractorTest`
2. **View full log:** `less test-logs/ArticleExtractorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ArticleExtractorTest`

