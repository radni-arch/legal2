# Support Bundle: bundle-20260107-220308

**Generated:** 2026-01-07T22:03:11+00:00
**Reason:** Consecutive failures threshold exceeded: focused:ArticleExtractorTest
**Branch:** claude/graph-enhancement-data-integrity-XqqqL
**Commit:** f2f3f24

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/ArticleExtractorTest.md
failures/CaseDecisionEvents.md
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingService.md
failures/CaseDecisionMatchingServiceTest.md
failures/CourtCaseDecisionMatch.md
failures/CourtCaseDecisionMatchTest.md
failures/CourtDecisionOutcomeColumnsTest.md
failures/CourtDecisionTagsUnicodeTest.md
failures/DecisionGraphSyncServiceTest.md
failures/EnhancedGraphSyncJobTest.md
failures/FetchPpPrzCasesIntegrationTest.md
failures/GraphConnectionExceptionTest.md
failures/GraphDataIntegrityServiceTest.md
failures/GraphSchemaApplyCommandTest.md
failures/GraphSyncExceptionTest.md
failures/GraphViewerTest.md
failures/LegalConceptExtractorTest.md
failures/LegalPrincipleGraphSyncServiceTest.md
failures/LegalPrincipleGraphSyncServiceTest__it_reuses_existing_principle_node_for_same_pattern.md
failures/LegalTopicExtractorTest.md
failures/MatchCaseDecisionsCommandTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/ReconcileUnmatchedCasesJobTest.md
failures/UnmatchedCasesReportCommandTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
f2f3f24 feat(graph): [G.3] Legal Concept Extraction - 103 Croatian legal concepts
00cb0d5 Feature: [G.1] Legal Topic Extraction System
b3f0b3b chore: update orchestrator logs
c980a06 chore: update session logs
da96ee3 test: Add constraint violation and injection prevention tests (C.3, C.5)
```
