# Failure Brief: LegalDefinitionExtractorTest

**Component:** `focused:LegalDefinitionExtractorTest`
**Generated:** 2026-01-08T01:13:30+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh LegalDefinitionExtractorTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Services/Graph/Extractors/LegalDefinitionExtractorTest.php:15
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/Extractors/LegalDefinitionExtractorTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh LegalDefinitionExtractorTest`
2. **View full log:** `less test-logs/LegalDefinitionExtractorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component LegalDefinitionExtractorTest`

