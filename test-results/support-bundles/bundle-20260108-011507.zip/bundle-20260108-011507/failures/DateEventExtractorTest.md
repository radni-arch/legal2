# Failure Brief: DateEventExtractorTest

**Component:** `focused:DateEventExtractorTest`
**Generated:** 2026-01-08T01:13:40+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh DateEventExtractorTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Services/Graph/Extractors/DateEventExtractorTest.php:16
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/Extractors/DateEventExtractorTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh DateEventExtractorTest`
2. **View full log:** `less test-logs/DateEventExtractorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component DateEventExtractorTest`

