# Failure Brief: EvidenceExtractorTest

**Component:** `focused:EvidenceExtractorTest`
**Generated:** 2026-01-08T01:13:38+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh EvidenceExtractorTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Services/Graph/Extractors/EvidenceExtractorTest.php:15
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/Extractors/EvidenceExtractorTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh EvidenceExtractorTest`
2. **View full log:** `less test-logs/EvidenceExtractorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component EvidenceExtractorTest`

