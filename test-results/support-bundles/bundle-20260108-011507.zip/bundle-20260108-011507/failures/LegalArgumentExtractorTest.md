# Failure Brief: LegalArgumentExtractorTest

**Component:** `focused:LegalArgumentExtractorTest`
**Generated:** 2026-01-08T01:13:46+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh LegalArgumentExtractorTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Services/Graph/Extractors/LegalArgumentExtractorTest.php:15
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/Extractors/LegalArgumentExtractorTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh LegalArgumentExtractorTest`
2. **View full log:** `less test-logs/LegalArgumentExtractorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component LegalArgumentExtractorTest`

