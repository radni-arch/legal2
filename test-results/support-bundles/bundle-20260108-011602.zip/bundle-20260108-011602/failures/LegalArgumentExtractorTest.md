# Failure Brief: LegalArgumentExtractorTest

**Component:** `focused:LegalArgumentExtractorTest`
**Generated:** 2026-01-08T01:15:18+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh LegalArgumentExtractorTest
```

---

## Failing Tests



---

## Error Messages

```
  Failed asserting that an array is not empty.
  Failed asserting that an array is not empty.
```

---

## Stack Frames

```
tests/Unit/Services/Graph/Extractors/LegalArgumentExtractorTest.php:178
tests/Unit/Services/Graph/Extractors/LegalArgumentExtractorTest.php:256
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/Extractors/LegalArgumentExtractorTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh LegalArgumentExtractorTest`
2. **View full log:** `less test-logs/LegalArgumentExtractorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component LegalArgumentExtractorTest`

