# Failure Brief: DateEventExtractorTest

**Component:** `focused:DateEventExtractorTest`
**Generated:** 2026-01-08T01:17:26+00:00
**Consecutive Failures:** 6

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh DateEventExtractorTest
```

---

## Failing Tests

- Tests\Unit\Services\Graph\Extractors\DateEventExtractorTest > it

---

## Error Messages

```
  Failed asserting that two strings are equal.
```

---

## Stack Frames

```
tests/Unit/Services/Graph/Extractors/DateEventExtractorTest.php:201
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/Extractors/DateEventExtractorTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh DateEventExtractorTest`
2. **View full log:** `less test-logs/DateEventExtractorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component DateEventExtractorTest`

