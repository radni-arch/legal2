# Failure Brief: EvidenceExtractorTest

**Component:** `focused:EvidenceExtractorTest`
**Generated:** 2026-01-08T01:18:35+00:00
**Consecutive Failures:** 5

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh EvidenceExtractorTest
```

---

## Failing Tests

- Tests\Unit\Services\Graph\Extractors\EvidenceExtractorTest > it

---

## Error Messages

```
  Failed asserting that an array is not empty.
  Failed asserting that an array is not empty.
  Failed asserting that an array is not empty.
  Failed asserting that an array is not empty.
```

---

## Stack Frames

```
tests/Unit/Services/Graph/Extractors/EvidenceExtractorTest.php:122
tests/Unit/Services/Graph/Extractors/EvidenceExtractorTest.php:136
tests/Unit/Services/Graph/Extractors/EvidenceExtractorTest.php:164
tests/Unit/Services/Graph/Extractors/EvidenceExtractorTest.php:192
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/Extractors/EvidenceExtractorTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh EvidenceExtractorTest`
2. **View full log:** `less test-logs/EvidenceExtractorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component EvidenceExtractorTest`

