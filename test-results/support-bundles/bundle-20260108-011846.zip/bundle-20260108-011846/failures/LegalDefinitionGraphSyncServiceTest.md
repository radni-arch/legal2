# Failure Brief: LegalDefinitionGraphSyncServiceTest

**Component:** `focused:LegalDefinitionGraphSyncServiceTest`
**Generated:** 2026-01-08T01:18:16+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh LegalDefinitionGraphSyncServiceTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Services/Graph/LegalDefinitionGraphSyncServiceTest.php:286
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/LegalDefinitionGraphSyncServiceTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh LegalDefinitionGraphSyncServiceTest`
2. **View full log:** `less test-logs/LegalDefinitionGraphSyncServiceTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component LegalDefinitionGraphSyncServiceTest`

