# RCA Draft: Repeated Failures

**Trigger:** 5 consecutive failures for `focused:EvidenceExtractorTest`
**Generated:** 2026-01-08T01:18:36+00:00
**Threshold:** 3

---

## Summary

The component `focused:EvidenceExtractorTest` has failed 5 times consecutively,
exceeding the RCA threshold of 3.

---

## Recent Failures (Last 5)

| Timestamp | Component | Outcome |
|-----------|-----------|---------|
| 2026-01-08T01:17:46+00:00 | `focused:EvidenceExtractorTest` | fail |
| 2026-01-08T01:18:11+00:00 | `focused:LegalDefinitionGraphSyncServiceTest` | fail |
| 2026-01-08T01:18:18+00:00 | `focused:LegalArgumentGraphSyncServiceTest` | fail |
| 2026-01-08T01:18:24+00:00 | `focused:DateEventExtractorTest` | fail |
| 2026-01-08T01:18:31+00:00 | `focused:EvidenceExtractorTest` | fail |

---

## Failure Pattern Analysis

**Questions to investigate:**

1. [ ] Is this a new failure or regression?
2. [ ] Did recent code changes affect this component?
3. [ ] Are there external dependencies involved (DB, API, network)?
4. [ ] Is this a flaky test or deterministic failure?
5. [ ] Are other related components also failing?

---

## Recommended Actions

1. **Review the failure brief:**
   ```bash
   cat test-results/failures/EvidenceExtractorTest.md
   ```

2. **Check recent commits:**
   ```bash
   git log --oneline -10
   ```

3. **Run with verbose output:**
   ```bash
   php artisan test --filter=EvidenceExtractorTest -vvv
   ```

4. **Check environment:**
   ```bash
   /check-setup
   ```

---

## Resolution

_Fill in after investigation:_

**Root Cause:**

**Fix Applied:**

**Verification:**

