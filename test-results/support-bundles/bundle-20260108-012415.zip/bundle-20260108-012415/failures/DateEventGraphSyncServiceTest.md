# Failure Brief: DateEventGraphSyncServiceTest

**Component:** `focused:DateEventGraphSyncServiceTest`
**Generated:** 2026-01-08T01:23:29+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh DateEventGraphSyncServiceTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Services/Graph/DateEventGraphSyncServiceTest.php:24
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/DateEventGraphSyncServiceTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh DateEventGraphSyncServiceTest`
2. **View full log:** `less test-logs/DateEventGraphSyncServiceTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component DateEventGraphSyncServiceTest`

