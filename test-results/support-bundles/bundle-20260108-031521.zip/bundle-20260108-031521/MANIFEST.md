# Support Bundle: bundle-20260108-031521

**Generated:** 2026-01-08T03:15:24+00:00
**Reason:** Consecutive failures threshold exceeded: focused:BatchCypherBuilderTest
**Branch:** claude/graph-enhancement-data-integrity-XqqqL
**Commit:** 076278f

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/ArticleExtractorTest.md
failures/CaseDecisionEvents.md
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingService.md
failures/CaseDecisionMatchingServiceTest.md
failures/CourtCaseDecisionMatch.md
failures/CourtCaseDecisionMatchTest.md
failures/CourtDecisionOutcomeColumnsTest.md
failures/CourtDecisionTagsUnicodeTest.md
failures/DateEventExtractorTest.md
failures/DateEventGraphSyncServiceTest.md
failures/DecisionGraphSyncServiceTest.md
failures/EnhancedGraphSyncJobTest.md
failures/EvidenceExtractorTest.md
failures/FetchPpPrzCasesIntegrationTest.md
failures/GraphConnectionExceptionTest.md
failures/GraphDataIntegrityServiceTest.md
failures/GraphSchemaApplyCommandTest.md
failures/GraphSyncExceptionTest.md
failures/GraphViewerTest.md
failures/LegalArgumentExtractorTest.md
failures/LegalArgumentGraphSyncServiceTest.md
failures/LegalConceptExtractorTest.md
failures/LegalDefinitionExtractorTest.md
failures/LegalDefinitionGraphSyncServiceTest.md
failures/LegalPrincipleGraphSyncServiceTest.md
failures/LegalPrincipleGraphSyncServiceTest__it_reuses_existing_principle_node_for_same_pattern.md
failures/LegalTopicExtractorTest.md
failures/MatchCaseDecisionsCommandTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/ReconcileUnmatchedCasesJobTest.md
failures/UnmatchedCasesReportCommandTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
076278f feat: [Sprint 3 - Task 2] Add BatchCypherBuilder service for UNWIND queries
5a54121 test: [Sprint 3 - A.1] Add BatchCypherBuilder test setup
0023506 chore: session logs
0e305d0 docs: Sprint 3 Performance Tuning detailed implementation plan (14 tasks)
f984b4b chore: session logs
```
