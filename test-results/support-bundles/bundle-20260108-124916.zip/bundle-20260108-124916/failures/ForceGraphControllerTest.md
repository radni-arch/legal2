# Failure Brief: ForceGraphControllerTest

**Component:** `focused:ForceGraphControllerTest`
**Generated:** 2026-01-08T12:47:39+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ForceGraphControllerTest
```

---

## Failing Tests

- Tests\Feature\Livewire\Graph\ForceGraphControllerTest > it

---

## Error Messages

```
  Failed asserting that null matches expected 'Case filed'.
  Failed asserting that null matches expected '2023-01-10'.
```

---

## Stack Frames

```
tests/Feature/Livewire/Graph/ForceGraphControllerTest.php:351
tests/Feature/Livewire/Graph/ForceGraphControllerTest.php:384
tests/Feature/Livewire/Graph/ForceGraphControllerTest.php:419
tests/Feature/Livewire/Graph/ForceGraphControllerTest.php:42
tests/Feature/Livewire/Graph/ForceGraphControllerTest.php:453
```

---

## Suspected Files

- `tests/Feature/Livewire/Graph/ForceGraphControllerTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ForceGraphControllerTest`
2. **View full log:** `less test-logs/ForceGraphControllerTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ForceGraphControllerTest`

