# Failure Brief: ForceGraphControllerTest

**Component:** `focused:ForceGraphControllerTest`
**Generated:** 2026-01-08T12:49:19+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ForceGraphControllerTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
app/Livewire/Graph/ForceGraphController.php:114
app/Livewire/Graph/ForceGraphController.php:75
```

---

## Suspected Files

- `app/Livewire/Graph/ForceGraphController.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ForceGraphControllerTest`
2. **View full log:** `less test-logs/ForceGraphControllerTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ForceGraphControllerTest`

