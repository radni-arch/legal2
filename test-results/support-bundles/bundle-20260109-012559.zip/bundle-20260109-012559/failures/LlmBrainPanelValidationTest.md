# Failure Brief: LlmBrainPanelValidationTest

**Component:** `focused:LlmBrainPanelValidationTest`
**Generated:** 2026-01-09T01:24:25+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh LlmBrainPanelValidationTest
```

---

## Failing Tests

- Tests\Feature\Livewire\LlmBrainPanelValidationTest > it

---

## Error Messages

```
  Failed asserting that 'No matching handler found for Mockery_0_App_Services_Graph_ReasoningChainService::executeReasoningChain('Find &lt;script&gt;alert("xss")&lt;/script&gt; decisions'). Either the method was unexpected or its arguments matched no expected argument list for this method\n
  Failed asserting that 'No matching handler found for Mockery_0_App_Services_Graph_ReasoningChainService::executeReasoningChain('Find all nodes MATCH (n) DELETE n'). Either the method was unexpected or its arguments matched no expected argument list for this method\n
  Failed asserting that 'Too many requests. Please wait before trying again.' matches expected null.
  Failed asserting that two strings are equal.
```

---

## Stack Frames

```
tests/Feature/Livewire/LlmBrainPanelValidationTest.php:104
tests/Feature/Livewire/LlmBrainPanelValidationTest.php:123
tests/Feature/Livewire/LlmBrainPanelValidationTest.php:144
tests/Feature/Livewire/LlmBrainPanelValidationTest.php:81
```

---

## Suspected Files

- `tests/Feature/Livewire/LlmBrainPanelValidationTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh LlmBrainPanelValidationTest`
2. **View full log:** `less test-logs/LlmBrainPanelValidationTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component LlmBrainPanelValidationTest`

