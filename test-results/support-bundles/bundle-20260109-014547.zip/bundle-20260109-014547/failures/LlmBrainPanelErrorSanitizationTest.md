# Failure Brief: LlmBrainPanelErrorSanitizationTest

**Component:** `focused:LlmBrainPanelErrorSanitizationTest`
**Generated:** 2026-01-09T01:44:43+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh LlmBrainPanelErrorSanitizationTest
```

---

## Failing Tests

- Tests\Feature\Livewire\LlmBrainPanelErrorSanitizationTest > it

---

## Error Messages

```
Failed asserting that 1148 is equal to 500 or is less than 500.
```

---

## Stack Frames

```
tests/Feature/Livewire/LlmBrainPanelErrorSanitizationTest.php:43
tests/Feature/Livewire/LlmBrainPanelErrorSanitizationTest.php:79
```

---

## Suspected Files

- `tests/Feature/Livewire/LlmBrainPanelErrorSanitizationTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh LlmBrainPanelErrorSanitizationTest`
2. **View full log:** `less test-logs/LlmBrainPanelErrorSanitizationTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component LlmBrainPanelErrorSanitizationTest`

