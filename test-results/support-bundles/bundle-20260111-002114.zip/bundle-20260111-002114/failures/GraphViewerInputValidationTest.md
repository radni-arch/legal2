# Failure Brief: GraphViewerInputValidationTest

**Component:** `focused:GraphViewerInputValidationTest`
**Generated:** 2026-01-11T00:20:17+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphViewerInputValidationTest
```

---

## Failing Tests

- Tests\Feature\Livewire\GraphViewerInputValidationTest > it

---

## Error Messages

```
  Failed asserting that 100 matches expected 5.
  Failed asserting that -5 matches expected 1.
```

---

## Stack Frames

```
tests/Feature/Livewire/GraphViewerInputValidationTest.php:111
tests/Feature/Livewire/GraphViewerInputValidationTest.php:126
tests/Feature/Livewire/GraphViewerInputValidationTest.php:140
tests/Feature/Livewire/GraphViewerInputValidationTest.php:168
tests/Feature/Livewire/GraphViewerInputValidationTest.php:93
```

---

## Suspected Files

- `tests/Feature/Livewire/GraphViewerInputValidationTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphViewerInputValidationTest`
2. **View full log:** `less test-logs/GraphViewerInputValidationTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphViewerInputValidationTest`

