# Support Bundle: bundle-20260111-005306

**Generated:** 2026-01-11T00:53:09+00:00
**Reason:** Consecutive failures threshold exceeded: focused:GraphExceptionHierarchyTest
**Branch:** claude/graph-enhancement-data-integrity-XqqqL
**Commit:** 271eb0a

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/AgentCypherQuerySafetyTest.md
failures/ArticleExtractorTest.md
failures/BatchCypherBuilderTest.md
failures/BatchOperationsBenchmarkTest.md
failures/CaseDecisionEvents.md
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingService.md
failures/CaseDecisionMatchingServiceTest.md
failures/CourtCaseDecisionMatch.md
failures/CourtCaseDecisionMatchTest.md
failures/CourtDecisionOutcomeColumnsTest.md
failures/CourtDecisionTagsUnicodeTest.md
failures/DateEventExtractorTest.md
failures/DateEventGraphSyncServiceTest.md
failures/DecisionGraphSyncServiceTest.md
failures/EnhancedGraphSyncJobTest.md
failures/EvidenceExtractorTest.md
failures/FetchPpPrzCasesIntegrationTest.md
failures/ForceGraphControllerTest.md
failures/GraphConnectionExceptionTest.md
failures/GraphDataIntegrityServiceTest.md
failures/GraphSchemaApplyCommandTest.md
failures/GraphSyncExceptionTest.md
failures/GraphViewerInputValidationTest.md
failures/GraphViewerTest.md
failures/GraphViewerXssProtectionTest.md
failures/IllegalSearchDetectorTest.md
failures/LegalArgumentExtractorTest.md
failures/LegalArgumentGraphSyncServiceTest.md
failures/LegalConceptExtractorTest.md
failures/LegalDefinitionExtractorTest.md
failures/LegalDefinitionGraphSyncServiceTest.md
failures/LegalPrincipleGraphSyncServiceTest.md
failures/LegalPrincipleGraphSyncServiceTest__it_reuses_existing_principle_node_for_same_pattern.md
failures/LegalTopicExtractorTest.md
failures/LlmBrainPanelErrorSanitizationTest.md
failures/LlmBrainPanelValidationTest.md
failures/LlmBrainPerformanceTest.md
failures/MatchCaseDecisionsCommandTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/ReconcileUnmatchedCasesJobTest.md
failures/UnmatchedCasesReportCommandTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
271eb0a security(agents): audit and verify Cypher query parameter binding
72b6e21 fix(graph): address code review issues for input validation
788c72c security(graph): add input validation to GraphViewer component
c0a7655 security(graph): add XSS protection tests for GraphViewer
423c3d3 docs(plan): add Neo4j production hardening implementation plan
```
