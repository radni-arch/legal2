# Failure Brief: GraphExceptionHierarchyTest

**Component:** `focused:GraphExceptionHierarchyTest`
**Generated:** 2026-01-11T00:53:09+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphExceptionHierarchyTest
```

---

## Failing Tests

- Tests\Unit\Exceptions\GraphExceptionHierarchyTest > all
- Tests\Unit\Exceptions\GraphExceptionHierarchyTest > graph

---

## Error Messages

```
Failed asserting that false is true.
     21▕             GraphTimeoutException::class,
     26▕                 is_subclass_of($exception, GraphException::class),
  ➜  36▕         $exception = GraphQueryException::forQuery($query, new \Exception('Neo4j error'));
  ➜  45▕         $exception = GraphTimeoutException::afterSeconds(30, 'Long query');
  ➜  55▕         $exception = GraphValidationException::withErrors($errors);
```

---

## Stack Frames

```
tests/Unit/Exceptions/GraphExceptionHierarchyTest.php:25
tests/Unit/Exceptions/GraphExceptionHierarchyTest.php:36
tests/Unit/Exceptions/GraphExceptionHierarchyTest.php:45
tests/Unit/Exceptions/GraphExceptionHierarchyTest.php:55
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Exceptions/GraphExceptionHierarchyTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphExceptionHierarchyTest`
2. **View full log:** `less test-logs/GraphExceptionHierarchyTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphExceptionHierarchyTest`

