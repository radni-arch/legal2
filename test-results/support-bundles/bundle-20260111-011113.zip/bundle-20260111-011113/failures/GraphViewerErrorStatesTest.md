# Failure Brief: GraphViewerErrorStatesTest

**Component:** `focused:GraphViewerErrorStatesTest`
**Generated:** 2026-01-11T01:10:18+00:00
**Consecutive Failures:** 4

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphViewerErrorStatesTest
```

---

## Failing Tests

- Tests\Feature\Livewire\GraphViewerErrorStatesTest > it

---

## Error Messages

```

```

---

## Stack Frames

```
tests/Feature/Livewire/GraphViewerErrorStatesTest.php:36
```

---

## Suspected Files

- `tests/Feature/Livewire/GraphViewerErrorStatesTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphViewerErrorStatesTest`
2. **View full log:** `less test-logs/GraphViewerErrorStatesTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphViewerErrorStatesTest`

