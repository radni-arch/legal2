# Failure Brief: GraphDatabaseServiceLoggingTest

**Component:** `focused:GraphDatabaseServiceLoggingTest`
**Generated:** 2026-01-11T01:23:47+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphDatabaseServiceLoggingTest
```

---

## Failing Tests

- Tests\Unit\Services\GraphDatabaseServiceLoggingTest > quer

---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Services/GraphDatabaseServiceLoggingTest.php:15
tests/Unit/Services/GraphDatabaseServiceLoggingTest.php:26
tests/Unit/Services/GraphDatabaseServiceLoggingTest.php:34
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/GraphDatabaseServiceLoggingTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphDatabaseServiceLoggingTest`
2. **View full log:** `less test-logs/GraphDatabaseServiceLoggingTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphDatabaseServiceLoggingTest`

