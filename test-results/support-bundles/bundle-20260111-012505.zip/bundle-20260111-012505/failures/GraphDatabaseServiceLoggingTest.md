# Failure Brief: GraphDatabaseServiceLoggingTest

**Component:** `focused:GraphDatabaseServiceLoggingTest`
**Generated:** 2026-01-11T01:24:31+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphDatabaseServiceLoggingTest
```

---

## Failing Tests

- Tests\Unit\Services\GraphDatabaseServiceLoggingTest > query

---

## Error Messages

```
  Failed asserting that 103 is equal to 100 or is less than 100.
```

---

## Stack Frames

```
tests/Unit/Services/GraphDatabaseServiceLoggingTest.php:17
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/GraphDatabaseServiceLoggingTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphDatabaseServiceLoggingTest`
2. **View full log:** `less test-logs/GraphDatabaseServiceLoggingTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphDatabaseServiceLoggingTest`

