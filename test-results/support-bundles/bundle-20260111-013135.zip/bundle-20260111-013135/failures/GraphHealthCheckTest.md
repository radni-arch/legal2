# Failure Brief: GraphHealthCheckTest

**Component:** `focused:GraphHealthCheckTest`
**Generated:** 2026-01-11T01:30:34+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphHealthCheckTest
```

---

## Failing Tests

- Tests\Feature\Api\GraphHealthCheckTest > health

---

## Error Messages

```
Failed asserting that 404 is identical to 200.
Failed asserting that 404 is identical to 503.
Failed asserting that 404 is identical to 200.
  Expected response status code [200] but received 404.
  Expected response status code [503] but received 404.
  Expected response status code [200] but received 404.
```

---

## Stack Frames

```
tests/Feature/Api/GraphHealthCheckTest.php:21
tests/Feature/Api/GraphHealthCheckTest.php:38
tests/Feature/Api/GraphHealthCheckTest.php:55
```

---

## Suspected Files

- `tests/Feature/Api/GraphHealthCheckTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphHealthCheckTest`
2. **View full log:** `less test-logs/GraphHealthCheckTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphHealthCheckTest`

