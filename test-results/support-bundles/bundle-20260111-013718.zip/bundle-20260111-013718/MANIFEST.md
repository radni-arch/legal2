# Support Bundle: bundle-20260111-013718

**Generated:** 2026-01-11T01:37:21+00:00
**Reason:** Consecutive failures threshold exceeded: focused:GraphInputSanitizerTest
**Branch:** claude/graph-enhancement-data-integrity-XqqqL
**Commit:** b3d3e75

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/AgentCypherQuerySafetyTest.md
failures/ArticleExtractorTest.md
failures/BatchCypherBuilderTest.md
failures/BatchOperationsBenchmarkTest.md
failures/CaseDecisionEvents.md
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingService.md
failures/CaseDecisionMatchingServiceTest.md
failures/CircuitBreakerIntegrationTest.md
failures/CourtCaseDecisionMatch.md
failures/CourtCaseDecisionMatchTest.md
failures/CourtDecisionOutcomeColumnsTest.md
failures/CourtDecisionTagsUnicodeTest.md
failures/DateEventExtractorTest.md
failures/DateEventGraphSyncServiceTest.md
failures/DecisionGraphSyncServiceTest.md
failures/EnhancedGraphSyncJobTest.md
failures/EvidenceExtractorTest.md
failures/FetchPpPrzCasesIntegrationTest.md
failures/ForceGraphControllerTest.md
failures/GraphConnectionExceptionTest.md
failures/GraphDataIntegrityServiceTest.md
failures/GraphDatabaseServiceLoggingTest.md
failures/GraphExceptionHierarchyTest.md
failures/GraphHealthCheckTest.md
failures/GraphInputSanitizerTest.md
failures/GraphSchemaApplyCommandTest.md
failures/GraphSyncExceptionTest.md
failures/GraphViewerErrorStatesTest.md
failures/GraphViewerInputValidationTest.md
failures/GraphViewerTest.md
failures/GraphViewerXssProtectionTest.md
failures/IllegalSearchDetectorTest.md
failures/LegalArgumentExtractorTest.md
failures/LegalArgumentGraphSyncServiceTest.md
failures/LegalConceptExtractorTest.md
failures/LegalDefinitionExtractorTest.md
failures/LegalDefinitionGraphSyncServiceTest.md
failures/LegalPrincipleGraphSyncServiceTest.md
failures/LegalPrincipleGraphSyncServiceTest__it_reuses_existing_principle_node_for_same_pattern.md
failures/LegalTopicExtractorTest.md
failures/LlmBrainPanelErrorSanitizationTest.md
failures/LlmBrainPanelValidationTest.md
failures/LlmBrainPerformanceTest.md
failures/MatchCaseDecisionsCommandTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/ReconcileUnmatchedCasesJobTest.md
failures/UnmatchedCasesReportCommandTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
b3d3e75 feat(api): add health check endpoint for Neo4j graph database
204ad4b feat(graph): add structured logging helpers for GraphDatabaseService
cb78c6e feat(ui): add error states and loading indicators to GraphViewer
4410bc3 test(graph): add circuit breaker integration tests
4271828 feat(graph): standardize exception hierarchy for Neo4j operations
```
