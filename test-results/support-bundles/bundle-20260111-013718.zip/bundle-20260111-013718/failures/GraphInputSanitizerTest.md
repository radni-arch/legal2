# Failure Brief: GraphInputSanitizerTest

**Component:** `focused:GraphInputSanitizerTest`
**Generated:** 2026-01-11T01:36:33+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphInputSanitizerTest
```

---

## Failing Tests

- Tests\Unit\Services\Graph\GraphInputSanitizerTest > it

---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Services/Graph/GraphInputSanitizerTest.php:15
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/GraphInputSanitizerTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphInputSanitizerTest`
2. **View full log:** `less test-logs/GraphInputSanitizerTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphInputSanitizerTest`

