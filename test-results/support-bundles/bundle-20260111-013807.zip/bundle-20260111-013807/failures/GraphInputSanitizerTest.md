# Failure Brief: GraphInputSanitizerTest

**Component:** `focused:GraphInputSanitizerTest`
**Generated:** 2026-01-11T01:37:22+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphInputSanitizerTest
```

---

## Failing Tests

- Tests\Unit\Services\Graph\GraphInputSanitizerTest > it

---

## Error Messages

```
  Failed asserting that two strings are equal.
```

---

## Stack Frames

```
tests/Unit/Services/Graph/GraphInputSanitizerTest.php:57
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/GraphInputSanitizerTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphInputSanitizerTest`
2. **View full log:** `less test-logs/GraphInputSanitizerTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphInputSanitizerTest`

