# Failure Brief: GraphConsistencyCheckCommandTest

**Component:** `focused:GraphConsistencyCheckCommandTest`
**Generated:** 2026-01-11T01:44:24+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphConsistencyCheckCommandTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Feature/Commands/GraphConsistencyCheckCommandTest.php:26
tests/Feature/Commands/GraphConsistencyCheckCommandTest.php:45
tests/Feature/Commands/GraphConsistencyCheckCommandTest.php:61
```

---

## Suspected Files

- `tests/Feature/Commands/GraphConsistencyCheckCommandTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphConsistencyCheckCommandTest`
2. **View full log:** `less test-logs/GraphConsistencyCheckCommandTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphConsistencyCheckCommandTest`

