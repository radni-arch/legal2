# Failure Brief: GraphConsistencyCheckCommandTest

**Component:** `focused:GraphConsistencyCheckCommandTest`
**Generated:** 2026-01-11T01:53:47+00:00
**Consecutive Failures:** 3

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh GraphConsistencyCheckCommandTest
```

---

## Failing Tests



---

## Error Messages

```
   FAILED  Tests\Feature\Commands\GraphConsistencyChec…  AssertionFailedError   
```

---

## Stack Frames

```
tests/Feature/Commands/GraphConsistencyCheckCommandTest.php:93
```

---

## Suspected Files

- `tests/Feature/Commands/GraphConsistencyCheckCommandTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh GraphConsistencyCheckCommandTest`
2. **View full log:** `less test-logs/GraphConsistencyCheckCommandTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component GraphConsistencyCheckCommandTest`

