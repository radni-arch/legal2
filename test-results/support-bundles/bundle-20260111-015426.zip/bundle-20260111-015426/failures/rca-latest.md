# RCA Draft: Repeated Failures

**Trigger:** 3 consecutive failures for `focused:GraphConsistencyCheckCommandTest`
**Generated:** 2026-01-11T01:53:48+00:00
**Threshold:** 3

---

## Summary

The component `focused:GraphConsistencyCheckCommandTest` has failed 3 times consecutively,
exceeding the RCA threshold of 3.

---

## Recent Failures (Last 5)

| Timestamp | Component | Outcome |
|-----------|-----------|---------|
| 2026-01-11T01:37:18+00:00 | `focused:GraphInputSanitizerTest` | fail |
| 2026-01-11T01:38:07+00:00 | `focused:GraphInputSanitizerTest` | fail |
| 2026-01-11T01:44:20+00:00 | `focused:GraphConsistencyCheckCommandTest` | fail |
| 2026-01-11T01:45:22+00:00 | `focused:GraphConsistencyCheckCommandTest` | fail |
| 2026-01-11T01:53:44+00:00 | `focused:GraphConsistencyCheckCommandTest` | fail |

---

## Failure Pattern Analysis

**Questions to investigate:**

1. [ ] Is this a new failure or regression?
2. [ ] Did recent code changes affect this component?
3. [ ] Are there external dependencies involved (DB, API, network)?
4. [ ] Is this a flaky test or deterministic failure?
5. [ ] Are other related components also failing?

---

## Recommended Actions

1. **Review the failure brief:**
   ```bash
   cat test-results/failures/GraphConsistencyCheckCommandTest.md
   ```

2. **Check recent commits:**
   ```bash
   git log --oneline -10
   ```

3. **Run with verbose output:**
   ```bash
   php artisan test --filter=GraphConsistencyCheckCommandTest -vvv
   ```

4. **Check environment:**
   ```bash
   /check-setup
   ```

---

## Resolution

_Fill in after investigation:_

**Root Cause:**

**Fix Applied:**

**Verification:**

