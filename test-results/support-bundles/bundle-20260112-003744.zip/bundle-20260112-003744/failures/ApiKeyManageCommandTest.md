# Failure Brief: ApiKeyManageCommandTest

**Component:** `focused:ApiKeyManageCommandTest`
**Generated:** 2026-01-12T00:36:56+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ApiKeyManageCommandTest
```

---

## Failing Tests

- Tests\Feature\Console\ApiKeyManageCommandTest > add
- Tests\Feature\Console\ApiKeyManageCommandTest > l

---

## Error Messages

```
  Failed asserting that null is not null.
```

---

## Stack Frames

```
tests/Feature/Console/ApiKeyManageCommandTest.php:377
tests/TestCase.php:18
```

---

## Suspected Files

- `tests/Feature/Console/ApiKeyManageCommandTest.php`
- `tests/TestCase.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ApiKeyManageCommandTest`
2. **View full log:** `less test-logs/ApiKeyManageCommandTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ApiKeyManageCommandTest`

