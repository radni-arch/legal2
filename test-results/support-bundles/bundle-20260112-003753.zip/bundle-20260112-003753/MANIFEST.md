# Support Bundle: bundle-20260112-003753

**Generated:** 2026-01-12T00:37:57+00:00
**Reason:** Consecutive failures threshold exceeded: focused:ApiKeyManageCommandTest
**Branch:** claude/smart-api-rotation-CGWXb
**Commit:** 1347fd4

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/ApiKeyManageCommandTest.md
failures/ApiKeyRotatorTest.md
failures/ApiKeyValidateCommandTest.md
failures/CaseDecisionEvents.md
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingService.md
failures/CaseDecisionMatchingServiceTest.md
failures/CourtCaseDecisionMatch.md
failures/CourtCaseDecisionMatchTest.md
failures/CourtDecisionTagsUnicodeTest.md
failures/FetchPpPrzCasesIntegrationTest.md
failures/GraphViewerTest.md
failures/MatchCaseDecisionsCommandTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/ReconcileUnmatchedCasesJobTest.md
failures/UnmatchedCasesReportCommandTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
1347fd4 chore: Sync logs
0d7ca2f chore: Session log update
ca444f8 chore: Session log update
656d6b2 chore: Final log sync
72fa054 chore: Update orchestrator session log
```
