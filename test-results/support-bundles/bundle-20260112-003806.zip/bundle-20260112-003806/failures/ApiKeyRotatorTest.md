# Failure Brief: ApiKeyRotatorTest

**Component:** `focused:ApiKeyRotatorTest`
**Generated:** 2026-01-12T00:37:23+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ApiKeyRotatorTest
```

---

## Failing Tests

- Tests\Feature\ApiKeyRotatorTest > key

---

## Error Messages

```
  Failed asserting that App\Models\ApiKey Object #80317 (
```

---

## Stack Frames

```
tests/Feature/ApiKeyRotatorTest.php:163
```

---

## Suspected Files

- `tests/Feature/ApiKeyRotatorTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ApiKeyRotatorTest`
2. **View full log:** `less test-logs/ApiKeyRotatorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ApiKeyRotatorTest`

