# Failure Brief: ApiKeyRotatorServiceTest

**Component:** `focused:ApiKeyRotatorServiceTest`
**Generated:** 2026-01-12T00:39:17+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ApiKeyRotatorServiceTest
```

---

## Failing Tests

- Tests\Unit\Services\ApiRotator\ApiKeyRotatorServiceTest > dispatc
- Tests\Unit\Services\ApiRotator\ApiKeyRotatorServiceTest > record
- Tests\Unit\Services\ApiRotator\ApiKeyRotatorServiceTest > service

---

## Error Messages

```
  Failed asserting that 12 matches expected 13.
  Failed asserting that a row in the table [api_key_usage_logs] matches the attributes {
Failed asserting that false is true.
Failed asserting that false is true.
```

---

## Stack Frames

```
database/migrations/0001_01_01_000000_create_users_table.php:14
database/migrations/2025_11_05_000000_add_actual_metadata_to_cases_documents_table.php:19
tests/TestCase.php:18
tests/Unit/Services/ApiRotator/ApiKeyRotatorServiceTest.php:26
tests/Unit/Services/ApiRotator/ApiKeyRotatorServiceTest.php:349
```

---

## Suspected Files

- `tests/TestCase.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/ApiRotator/ApiKeyRotatorServiceTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ApiKeyRotatorServiceTest`
2. **View full log:** `less test-logs/ApiKeyRotatorServiceTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ApiKeyRotatorServiceTest`

