# Failure Brief: ApiKeyRotatorTest

**Component:** `focused:ApiKeyRotatorTest`
**Generated:** 2026-01-12T00:38:10+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ApiKeyRotatorTest
```

---

## Failing Tests

- Tests\Feature\ApiKeyRotatorTest > create
- Tests\Feature\ApiKeyRotatorTest > exhausted
- Tests\Feature\ApiKeyRotatorTest > get
- Tests\Feature\ApiKeyRotatorTest > inactive
- Tests\Feature\ApiKeyRotatorTest > key
- Tests\Feature\ApiKeyRotatorTest > pdf
- Tests\Feature\ApiKeyRotatorTest > preferred
- Tests\Feature\ApiKeyRotatorTest > reset

---

## Error Messages

```

```

---

## Stack Frames

```
database/migrations/2025_10_23_000000_create_chat_conversations_table.php:11
database/migrations/2025_11_11_015305_add_feedback_fields_to_orchestration_logs_table.php:18
tests/TestCase.php:18
```

---

## Suspected Files

- `tests/TestCase.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ApiKeyRotatorTest`
2. **View full log:** `less test-logs/ApiKeyRotatorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ApiKeyRotatorTest`

