# RCA Draft: Repeated Failures

**Trigger:** 3 consecutive failures for `focused:GraphViewerTest`
**Generated:** 2026-01-07T03:47:03+00:00
**Threshold:** 3

---

## Summary

The component `focused:GraphViewerTest` has failed 3 times consecutively,
exceeding the RCA threshold of 3.

---

## Recent Failures (Last 5)

| Timestamp | Component | Outcome |
|-----------|-----------|---------|
| 2026-01-06T14:38:13+00:00 | `focused:GraphViewerTest` | fail |
| 2026-01-06T14:40:04+00:00 | `focused:GraphViewerTest` | fail |
| 2026-01-07T01:02:11+00:00 | `focused:CourtDecisionTagsUnicodeTest` | fail |
| 2026-01-07T01:05:21+00:00 | `focused:CourtDecisionTagsUnicodeTest` | fail |
| 2026-01-07T03:46:59+00:00 | `focused:GraphViewerTest` | fail |

---

## Failure Pattern Analysis

**Questions to investigate:**

1. [ ] Is this a new failure or regression?
2. [ ] Did recent code changes affect this component?
3. [ ] Are there external dependencies involved (DB, API, network)?
4. [ ] Is this a flaky test or deterministic failure?
5. [ ] Are other related components also failing?

---

## Recommended Actions

1. **Review the failure brief:**
   ```bash
   cat test-results/failures/GraphViewerTest.md
   ```

2. **Check recent commits:**
   ```bash
   git log --oneline -10
   ```

3. **Run with verbose output:**
   ```bash
   php artisan test --filter=GraphViewerTest -vvv
   ```

4. **Check environment:**
   ```bash
   /check-setup
   ```

---

## Resolution

_Fill in after investigation:_

**Root Cause:**

**Fix Applied:**

**Verification:**

