# Failure Brief: ApiKeyRotatorServiceTest

**Component:** `focused:ApiKeyRotatorServiceTest`
**Generated:** 2026-01-12T00:42:04+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ApiKeyRotatorServiceTest
```

---

## Failing Tests

- Tests\Unit\Services\ApiRotator\ApiKeyRotatorServiceTest > service

---

## Error Messages

```
  Failed asserting that 12 matches expected 13.
```

---

## Stack Frames

```
database/migrations/0001_01_01_000000_create_users_table.php:14
database/migrations/0001_01_01_000001_create_cache_table.php:14
database/migrations/2025_11_11_040000_create_emerging_entities_table.php:27
tests/TestCase.php:18
tests/Unit/Services/ApiRotator/ApiKeyRotatorServiceTest.php:26
tests/Unit/Services/ApiRotator/ApiKeyRotatorServiceTest.php:349
```

---

## Suspected Files

- `tests/TestCase.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/ApiRotator/ApiKeyRotatorServiceTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ApiKeyRotatorServiceTest`
2. **View full log:** `less test-logs/ApiKeyRotatorServiceTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ApiKeyRotatorServiceTest`

