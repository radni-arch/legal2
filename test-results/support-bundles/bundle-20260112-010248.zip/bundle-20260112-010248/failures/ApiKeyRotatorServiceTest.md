# Failure Brief: ApiKeyRotatorServiceTest

**Component:** `focused:ApiKeyRotatorServiceTest`
**Generated:** 2026-01-12T01:02:37+00:00
**Consecutive Failures:** 3

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ApiKeyRotatorServiceTest
```

---

## Failing Tests

- Tests\Unit\Services\ApiRotator\ApiKeyRotatorServiceTest > exponen

---

## Error Messages

```
Failed asserting that 0.022036075592041016 is greater than 0.2.
```

---

## Stack Frames

```
database/migrations/2025_01_29_210000_create_failed_ingestions_table.php:14
tests/TestCase.php:18
tests/Unit/Services/ApiRotator/ApiKeyRotatorServiceTest.php:541
```

---

## Suspected Files

- `tests/TestCase.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/ApiRotator/ApiKeyRotatorServiceTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ApiKeyRotatorServiceTest`
2. **View full log:** `less test-logs/ApiKeyRotatorServiceTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ApiKeyRotatorServiceTest`

