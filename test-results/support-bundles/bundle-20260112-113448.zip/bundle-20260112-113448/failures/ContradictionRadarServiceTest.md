# Failure Brief: ContradictionRadarServiceTest

**Component:** `focused:ContradictionRadarServiceTest`
**Generated:** 2026-01-12T11:33:47+00:00
**Consecutive Failures:** 4

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ContradictionRadarServiceTest
```

---

## Failing Tests

- Tests\Unit\Services\Graph\ContradictionRadarServiceTest > it

---

## Error Messages

```
  Failed asserting that exception of type "Error" matches expected exception "InvalidArgumentException". Message was: "Call to undefined method App\Services\Graph\ContradictionRadarService::findOverruledPrecedentCitations()" at
```

---

## Stack Frames

```
/home/user/ai-legal-war-machine/tests/Unit/Services/Graph/ContradictionRadarServiceTest.php:428
tests/Unit/Services/Graph/ContradictionRadarServiceTest.php:392
tests/Unit/Services/Graph/ContradictionRadarServiceTest.php:414
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Graph/ContradictionRadarServiceTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ContradictionRadarServiceTest`
2. **View full log:** `less test-logs/ContradictionRadarServiceTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ContradictionRadarServiceTest`

