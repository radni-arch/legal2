# Failure Brief: ContradictionRadarServiceTest

**Component:** `focused:ContradictionRadarServiceTest`
**Generated:** 2026-01-12T11:34:52+00:00
**Consecutive Failures:** 5

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh ContradictionRadarServiceTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```

```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh ContradictionRadarServiceTest`
2. **View full log:** `less test-logs/ContradictionRadarServiceTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component ContradictionRadarServiceTest`

