# Failure Brief: IllegalSearchDetectorTest

**Component:** `focused:IllegalSearchDetectorTest`
**Generated:** 2026-01-08T15:49:05+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh IllegalSearchDetectorTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```

```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh IllegalSearchDetectorTest`
2. **View full log:** `less test-logs/IllegalSearchDetectorTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component IllegalSearchDetectorTest`

