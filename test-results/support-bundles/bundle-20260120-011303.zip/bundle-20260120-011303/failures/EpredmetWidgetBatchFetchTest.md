# Failure Brief: EpredmetWidgetBatchFetchTest

**Component:** `focused:EpredmetWidgetBatchFetchTest`
**Generated:** 2026-01-20T01:11:29+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh EpredmetWidgetBatchFetchTest
```

---

## Failing Tests

- Tests\Feature\Livewire\EpredmetWidgetBatchFetchTest > widget

---

## Error Messages

```
  Failed asserting that null matches expected 2026.
```

---

## Stack Frames

```
tests/Feature/Livewire/EpredmetWidgetBatchFetchTest.php:101
tests/Feature/Livewire/EpredmetWidgetBatchFetchTest.php:117
tests/Feature/Livewire/EpredmetWidgetBatchFetchTest.php:25
tests/Feature/Livewire/EpredmetWidgetBatchFetchTest.php:33
tests/Feature/Livewire/EpredmetWidgetBatchFetchTest.php:42
tests/Feature/Livewire/EpredmetWidgetBatchFetchTest.php:54
tests/Feature/Livewire/EpredmetWidgetBatchFetchTest.php:65
tests/Feature/Livewire/EpredmetWidgetBatchFetchTest.php:74
tests/Feature/Livewire/EpredmetWidgetBatchFetchTest.php:88
```

---

## Suspected Files

- `tests/Feature/Livewire/EpredmetWidgetBatchFetchTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh EpredmetWidgetBatchFetchTest`
2. **View full log:** `less test-logs/EpredmetWidgetBatchFetchTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component EpredmetWidgetBatchFetchTest`

