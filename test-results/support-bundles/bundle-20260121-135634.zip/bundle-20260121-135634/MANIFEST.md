# Support Bundle: bundle-20260121-135634

**Generated:** 2026-01-21T13:56:37+00:00
**Reason:** Consecutive failures threshold exceeded: focused:UnifiedSearchTest
**Branch:** claude/fix-search-api-error-nNqgq
**Commit:** 033b2f4

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/ApiKeyManageCommandTest.md
failures/ApiKeyRotatorServiceTest.md
failures/ApiKeyRotatorTest.md
failures/ApiKeyValidateCommandTest.md
failures/CaseDecisionEvents.md
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingService.md
failures/CaseDecisionMatchingServiceTest.md
failures/CourtCaseDecisionMatch.md
failures/CourtCaseDecisionMatchTest.md
failures/CourtDecisionTagsUnicodeTest.md
failures/EpredmetWidget.md
failures/EpredmetWidgetBatchFetchTest.md
failures/FetchCourtCasesJob.md
failures/FetchPpPrzCasesIntegrationTest.md
failures/GraphDatabaseHealthTest.md
failures/GraphViewerTest.md
failures/MatchCaseDecisionsCommandTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/ReconcileUnmatchedCasesJobTest.md
failures/UnifiedSearchTest.md
failures/UnmatchedCasesReportCommandTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
033b2f4 Merge pull request #595 from aglavas/claude/fix-law-id-constraint-dj0E0
8624a6d chore: Final session log update
8813ad3 chore: Update orchestrator log
f5aeed5 chore: Update test artifacts and session logs
41e7b43 Merge pull request #594 from aglavas/claude/add-supervisor-config-qr0BZ
```
