# Failure Brief: UnifiedSearchTest

**Component:** `focused:UnifiedSearchTest`
**Generated:** 2026-01-21T13:55:59+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh UnifiedSearchTest
```

---

## Failing Tests

- Tests\Feature\Livewire\UnifiedSearchTest > combine

---

## Error Messages

```

```

---

## Stack Frames

```
storage/framework/views/ac87f35523044e22419a7a5bbfbfe5f3.php:645
tests/Feature/Livewire/UnifiedSearchTest.php:1034
tests/Feature/Livewire/UnifiedSearchTest.php:984
```

---

## Suspected Files

- `tests/Feature/Livewire/UnifiedSearchTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh UnifiedSearchTest`
2. **View full log:** `less test-logs/UnifiedSearchTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component UnifiedSearchTest`

