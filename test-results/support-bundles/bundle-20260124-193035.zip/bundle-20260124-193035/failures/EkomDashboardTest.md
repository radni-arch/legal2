# Failure Brief: EkomDashboardTest

**Component:** `focused:EkomDashboardTest`
**Generated:** 2026-01-24T19:28:06+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh EkomDashboardTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
routes/web.php:109
routes/web.php:110
```

---

## Suspected Files



---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh EkomDashboardTest`
2. **View full log:** `less test-logs/EkomDashboardTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component EkomDashboardTest`

