# Failure Brief: EkomDashboardTest

**Component:** `focused:EkomDashboardTest`
**Generated:** 2026-01-24T19:32:04+00:00
**Consecutive Failures:** 3

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh EkomDashboardTest
```

---

## Failing Tests

- Tests\Feature\Livewire\EkomDashboardTest > refresh

---

## Error Messages

```
      NunoMaduro\Collision\Exceptions\TestException::("Undefined array key "predmeti_count" (View: /home/user/ai-legal-war-machine/resources/views/livewire/ekom-dashboard.blade.php)")
```

---

## Stack Frames

```
storage/framework/views/2ce9742125bbe9e5cddf76f6ffd2cb04.php:85
tests/Feature/Livewire/EkomDashboardTest.php:35
```

---

## Suspected Files

- `tests/Feature/Livewire/EkomDashboardTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh EkomDashboardTest`
2. **View full log:** `less test-logs/EkomDashboardTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component EkomDashboardTest`

