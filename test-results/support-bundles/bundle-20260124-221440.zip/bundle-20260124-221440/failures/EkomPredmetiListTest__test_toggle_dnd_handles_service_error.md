# Failure Brief: EkomPredmetiListTest__test_toggle_dnd_handles_service_error

**Component:** `focused:EkomPredmetiListTest__test_toggle_dnd_handles_service_error`
**Generated:** 2026-01-24T22:13:46+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh EkomPredmetiListTest__test_toggle_dnd_handles_service_error
```

---

## Failing Tests

- Tests\Feature\Livewire\EkomPredmetiListTest > toggle

---

## Error Messages

```

```

---

## Stack Frames

```
tests/Feature/Livewire/EkomPredmetiListTest.php:279
```

---

## Suspected Files

- `tests/Feature/Livewire/EkomPredmetiListTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh EkomPredmetiListTest__test_toggle_dnd_handles_service_error`
2. **View full log:** `less test-logs/EkomPredmetiListTest__test_toggle_dnd_handles_service_error-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component EkomPredmetiListTest__test_toggle_dnd_handles_service_error`

