# Failure Brief: EkomSyncAllJobTest

**Component:** `focused:EkomSyncAllJobTest`
**Generated:** 2026-01-24T20:19:47+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh EkomSyncAllJobTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```

```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh EkomSyncAllJobTest`
2. **View full log:** `less test-logs/EkomSyncAllJobTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component EkomSyncAllJobTest`

