# Failure Brief: TextractServiceTest

**Component:** `focused:TextractServiceTest`
**Generated:** 2026-01-21T23:47:58+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh TextractServiceTest
```

---

## Failing Tests

- Tests\Unit\Services\TextractServiceTest > waits

---

## Error Messages

```
  Failed asserting that exception of type "Mockery\Exception\BadMethodCallException" matches expected exception "RuntimeException". Message was: "Received Mockery_2_Illuminate_Log_LogManager::info(), but no expectations were specified" at
```

---

## Stack Frames

```
/home/user/ai-legal-war-machine/app/Services/CircuitBreaker.php:90
/home/user/ai-legal-war-machine/app/Services/TextractService.php:256
/home/user/ai-legal-war-machine/tests/Unit/Services/TextractServiceTest.php:550
app/Services/CircuitBreaker.php:68
app/Services/TextractService.php:67
```

---

## Suspected Files

- `app/Services/CircuitBreaker.php`
- `app/Services/TextractService.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/TextractServiceTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh TextractServiceTest`
2. **View full log:** `less test-logs/TextractServiceTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component TextractServiceTest`

