# Failure Brief: EkomApiClientTest

**Component:** `focused:EkomApiClientTest`
**Generated:** 2026-01-25T08:03:20+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh EkomApiClientTest
```

---

## Failing Tests

- Tests\Unit\Clients\Ekom\EkomApiClientTest > get

---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Clients/Ekom/EkomApiClientTest.php:119
tests/Unit/Clients/Ekom/EkomApiClientTest.php:137
tests/Unit/Clients/Ekom/EkomApiClientTest.php:155
```

---

## Suspected Files

- `tests/Unit/Clients/Ekom/EkomApiClientTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh EkomApiClientTest`
2. **View full log:** `less test-logs/EkomApiClientTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component EkomApiClientTest`

