# Failure Brief: EkomApiClientTest

**Component:** `focused:EkomApiClientTest`
**Generated:** 2026-01-25T08:04:08+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh EkomApiClientTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```

```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh EkomApiClientTest`
2. **View full log:** `less test-logs/EkomApiClientTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component EkomApiClientTest`

