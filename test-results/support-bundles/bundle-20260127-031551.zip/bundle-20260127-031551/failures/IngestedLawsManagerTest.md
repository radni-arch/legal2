# Failure Brief: IngestedLawsManagerTest

**Component:** `focused:IngestedLawsManagerTest`
**Generated:** 2026-01-25T18:08:02+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh IngestedLawsManagerTest
```

---

## Failing Tests



---

## Error Messages

```
PHP Fatal error:  Uncaught Error: Failed opening required '/home/user/ai-legal-war-machine/vendor/autoload.php' (include_path='.:/usr/share/php') in /home/user/ai-legal-war-machine/artisan:10
```

---

## Stack Frames

```

```

---

## Suspected Files



---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh IngestedLawsManagerTest`
2. **View full log:** `less test-logs/IngestedLawsManagerTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component IngestedLawsManagerTest`

