# Support Bundle: bundle-20260127-033218

**Generated:** 2026-01-27T03:32:22+00:00
**Reason:** Consecutive failures threshold exceeded: focused:BreadcrumbServiceTest
**Branch:** claude/add-breadcrumbs-navigation-r6Hx3
**Commit:** e9d923b

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/ApiKeyManageCommandTest.md
failures/ApiKeyRotatorServiceTest.md
failures/ApiKeyRotatorTest.md
failures/ApiKeyValidateCommandTest.md
failures/BreadcrumbServiceTest.md
failures/CaseDecisionEvents.md
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingService.md
failures/CaseDecisionMatchingServiceTest.md
failures/CourtCaseDecisionMatch.md
failures/CourtCaseDecisionMatchTest.md
failures/CourtDecisionTagsUnicodeTest.md
failures/EkomApiClientTest.md
failures/EkomApiTest.md
failures/EkomDashboardTest.md
failures/EkomPredmetiListTest.md
failures/EkomPredmetiListTest__test_toggle_dnd_handles_service_error.md
failures/EkomSyncAllJobTest.md
failures/EpredmetWidget.md
failures/EpredmetWidgetBatchFetchTest.md
failures/FetchCourtCasesJob.md
failures/FetchPpPrzCasesIntegrationTest.md
failures/GraphDatabaseHealthTest.md
failures/GraphViewerTest.md
failures/IngestedLawsManagerTest.md
failures/LawVectorStoreServiceTest.md
failures/LogViewerServiceTest.md
failures/MatchCaseDecisionsCommandTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/ReconcileUnmatchedCasesJobTest.md
failures/TextractServiceTest.md
failures/UnifiedSearchServiceFullTextFallbackTest.md
failures/UnifiedSearchTest.md
failures/UnmatchedCasesReportCommandTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
e9d923b feat(breadcrumbs): Add BreadcrumbService with route registry
5539be1 feat(breadcrumbs): Add Breadcrumb value object
aa043e2 docs: Add breadcrumbs navigation implementation plan
ead1a06 Merge pull request #617 from aglavas/claude/fix-livewire-download-law-7eYLe
5a71abf Chore: Update test results and session logs
```
