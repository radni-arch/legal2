# Failure Brief: BreadcrumbServiceTest

**Component:** `focused:BreadcrumbServiceTest`
**Generated:** 2026-01-27T03:32:22+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh BreadcrumbServiceTest
```

---

## Failing Tests

- Tests\Unit\Services\Navigation\BreadcrumbServiceTest > ser

---

## Error Messages

```

```

---

## Stack Frames

```
tests/Unit/Services/Navigation/BreadcrumbServiceTest.php:113
```

---

## Suspected Files

- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`
- `tests/Unit/Services/Navigation/BreadcrumbServiceTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh BreadcrumbServiceTest`
2. **View full log:** `less test-logs/BreadcrumbServiceTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component BreadcrumbServiceTest`

