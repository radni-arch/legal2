# Failure Brief: OpenAIVectorManagerTest

**Component:** `focused:OpenAIVectorManagerTest`
**Generated:** 2026-01-31T02:34:53+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh OpenAIVectorManagerTest
```

---

## Failing Tests

- Tests\Feature\Livewire\OpenAIVectorManagerTest > cl
- Tests\Feature\Livewire\OpenAIVectorManagerTest > co
- Tests\Feature\Livewire\OpenAIVectorManagerTest > er
- Tests\Feature\Livewire\OpenAIVectorManagerTest > error
- Tests\Feature\Livewire\OpenAIVectorManagerTest > fe
- Tests\Feature\Livewire\OpenAIVectorManagerTest > lo
- Tests\Feature\Livewire\OpenAIVectorManagerTest > pe
- Tests\Feature\Livewire\OpenAIVectorManagerTest > re
- Tests\Feature\Livewire\OpenAIVectorManagerTest > sa
- Tests\Feature\Livewire\OpenAIVectorManagerTest > se

---

## Error Messages

```
  Failed asserting that null matches expected 'OpenAI API error: Invalid API key'.
```

---

## Stack Frames

```
tests/Feature/Livewire/OpenAIVectorManagerTest.php:215
tests/Feature/Livewire/OpenAIVectorManagerTest.php:32
tests/TestCase.php:18
```

---

## Suspected Files

- `tests/DuskTestCase.php`
- `tests/Feature/Livewire/OpenAIVectorManagerTest.php`
- `tests/TestCase.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh OpenAIVectorManagerTest`
2. **View full log:** `less test-logs/OpenAIVectorManagerTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component OpenAIVectorManagerTest`

