# Support Bundle: bundle-20260131-032512

**Generated:** 2026-01-31T03:25:18+00:00
**Reason:** Consecutive failures threshold exceeded: focused:LaravelLogViewerTest
**Branch:** claude/improve-vectors-ui-performance-DCAnJ
**Commit:** ec1c84c

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/AgentCypherQuerySafetyTest.md
failures/ApiKeyManageCommandTest.md
failures/ApiKeyRotatorServiceTest.md
failures/ApiKeyRotatorTest.md
failures/ApiKeyValidateCommandTest.md
failures/ArticleExtractorTest.md
failures/BatchCypherBuilderTest.md
failures/BatchOperationsBenchmarkTest.md
failures/BreadcrumbServiceTest.md
failures/CaseDecisionEvents.md
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingService.md
failures/CaseDecisionMatchingServiceTest.md
failures/CircuitBreakerIntegrationTest.md
failures/ContextAnalyzerTest.md
failures/ContradictionRadarServiceTest.md
failures/CourtCaseDecisionMatch.md
failures/CourtCaseDecisionMatchTest.md
failures/CourtDecisionOutcomeColumnsTest.md
failures/CourtDecisionTagsUnicodeTest.md
failures/DateEventExtractorTest.md
failures/DateEventGraphSyncServiceTest.md
failures/DecisionGraphSyncServiceTest.md
failures/EkomApiClientTest.md
failures/EkomApiTest.md
failures/EkomDashboardTest.md
failures/EkomPredmetiListTest.md
failures/EkomPredmetiListTest__test_toggle_dnd_handles_service_error.md
failures/EkomSyncAllJobTest.md
failures/EnhancedGraphSyncJobTest.md
failures/EpredmetWidget.md
failures/EpredmetWidgetBatchFetchTest.md
failures/EpredmetWidgetTest.md
failures/EvidenceExtractorTest.md
failures/FetchCourtCasesJob.md
failures/FetchPpPrzCasesIntegrationTest.md
failures/ForceGraphControllerTest.md
failures/GraphConnectionExceptionTest.md
failures/GraphConsistencyCheckCommandTest.md
failures/GraphDataIntegrityServiceTest.md
failures/GraphDatabaseHealthTest.md
failures/GraphDatabaseServiceLoggingTest.md
failures/GraphDatabaseServiceTest.md
failures/GraphExceptionHierarchyTest.md
failures/GraphHealthCheckTest.md
failures/GraphInputSanitizerTest.md
failures/GraphSchemaApplyCommandTest.md
failures/GraphSyncExceptionTest.md
failures/GraphViewerErrorStatesTest.md
failures/GraphViewerInputValidationTest.md
failures/GraphViewerTest.md
failures/GraphViewerXssProtectionTest.md
failures/IllegalSearchDetectorTest.md
failures/IngestedLawsManagerTest.md
failures/LaravelLogViewerTest.md
failures/LawVectorStoreServiceTest.md
failures/LegalArgumentExtractorTest.md
failures/LegalArgumentGraphSyncServiceTest.md
failures/LegalConceptExtractorTest.md
failures/LegalDefinitionExtractorTest.md
failures/LegalDefinitionGraphSyncServiceTest.md
failures/LegalPlaygroundTest.md
failures/LegalPrincipleGraphSyncServiceTest.md
failures/LegalPrincipleGraphSyncServiceTest__it_reuses_existing_principle_node_for_same_pattern.md
failures/LegalTopicExtractorTest.md
failures/LlmBrainPanelErrorSanitizationTest.md
failures/LlmBrainPanelValidationTest.md
failures/LlmBrainPerformanceTest.md
failures/LogViewerServiceTest.md
failures/MatchCaseDecisionsCommandTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/OpenAIVectorManagerTest.md
failures/ReconcileUnmatchedCasesJobTest.md
failures/SuppressionMotionGeneratorTest.md
failures/TextractServiceTest.md
failures/TopicAnalyzerTest.md
failures/TopicFrameworkIntegrationTest.md
failures/UnifiedSearchServiceFullTextFallbackTest.md
failures/UnifiedSearchTest.md
failures/UnmatchedCasesReportCommandTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 53
todo: 539
```

### Recent Commits
```
ec1c84c chore: add test results and agent logs from UI improvement session
e0f303d feat: improve vectors UI and logs viewer with pagination, caching, and layout
71a4b7d Merge pull request #666 from aglavas/claude/fix-uninitialized-property-jA7sy
e3e6b6a Merge branch 'master' into claude/fix-uninitialized-property-jA7sy
5d68436 Merge pull request #665 from aglavas/claude/fix-dashboard-null-error-gZ72a
```
