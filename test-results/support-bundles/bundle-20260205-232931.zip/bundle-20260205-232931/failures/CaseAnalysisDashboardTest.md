# Failure Brief: CaseAnalysisDashboardTest

**Component:** `focused:CaseAnalysisDashboardTest`
**Generated:** 2026-02-05T23:27:50+00:00
**Consecutive Failures:** 1

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh CaseAnalysisDashboardTest
```

---

## Failing Tests

- Tests\Feature\Livewire\CaseAnalysisDashboardTest > it

---

## Error Messages

```
  Failed asserting that an event [notify] was fired with parameters: {"type":"success","message":"Analysis queued for retry"}
Failed asserting that false is true.
  ➜  24▕         PHPUnit::assertTrue($result['test'], "Failed asserting that an event [{$event}] was fired{$result['assertionSuffix']}");
  Failed asserting that an event [notify] was fired with parameters: {"type":"error","message":"Analysis cannot be retried"}
Failed asserting that false is true.
  ➜  24▕         PHPUnit::assertTrue($result['test'], "Failed asserting that an event [{$event}] was fired{$result['assertionSuffix']}");
  Failed asserting that an event [notify] was fired with parameters: {"type":"success","message":"2 analyses queued for retry"}
Failed asserting that false is true.
  ➜  24▕         PHPUnit::assertTrue($result['test'], "Failed asserting that an event [{$event}] was fired{$result['assertionSuffix']}");
  Failed asserting that an event [notify] was fired with parameters: {"type":"success","message":"2 analyses queued for retry"}
  Expected response status code [403] but received 500.
```

---

## Stack Frames

```
/home/user/ai-legal-war-machine/app/Livewire/CaseAnalysisDashboard.php:45
/home/user/ai-legal-war-machine/app/Policies/LegalCasePolicy.php:22
/home/user/ai-legal-war-machine/storage/framework/views/d7de36a8b2692de70bab3211949ee568.php:7
/home/user/ai-legal-war-machine/tests/Feature/Livewire/CaseAnalysisDashboardTest.php:592
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:407
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:430
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:462
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:496
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:544
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:562
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:581
```

---

## Suspected Files

- `app/Livewire/CaseAnalysisDashboard.php`
- `app/Policies/LegalCasePolicy.php`
- `tests/Feature/Livewire/CaseAnalysisDashboardTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh CaseAnalysisDashboardTest`
2. **View full log:** `less test-logs/CaseAnalysisDashboardTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component CaseAnalysisDashboardTest`

