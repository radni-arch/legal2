# Failure Brief: CaseAnalysisDashboardTest

**Component:** `focused:CaseAnalysisDashboardTest`
**Generated:** 2026-02-05T23:29:34+00:00
**Consecutive Failures:** 2

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh CaseAnalysisDashboardTest
```

---

## Failing Tests

- Tests\Feature\Livewire\CaseAnalysisDashboardTest > it

---

## Error Messages

```
  Failed asserting that an event [notify] was fired.
Failed asserting that false is true.
  ➜  24▕         PHPUnit::assertTrue($result['test'], "Failed asserting that an event [{$event}] was fired{$result['assertionSuffix']}");
  Failed asserting that an event [notify] was fired.
Failed asserting that false is true.
  ➜  24▕         PHPUnit::assertTrue($result['test'], "Failed asserting that an event [{$event}] was fired{$result['assertionSuffix']}");
  Failed asserting that exception of type "Symfony\Component\HttpKernel\Exception\HttpException" is thrown.
  Failed asserting that exception of type "Illuminate\View\ViewException" matches expected exception "Illuminate\Auth\Access\AuthorizationException". Message was: "SQLSTATE[42P01]: Undefined table: 7 ERROR:  relation "case_user" does not exist
```

---

## Stack Frames

```
/home/user/ai-legal-war-machine/app/Policies/LegalCasePolicy.php:22
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:407
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:432
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:466
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:467
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:502
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:503
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:571
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:572
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:592
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:593
```

---

## Suspected Files

- `app/Livewire/CaseAnalysisDashboard.php`
- `app/Policies/LegalCasePolicy.php`
- `tests/Feature/Livewire/CaseAnalysisDashboardTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh CaseAnalysisDashboardTest`
2. **View full log:** `less test-logs/CaseAnalysisDashboardTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component CaseAnalysisDashboardTest`

