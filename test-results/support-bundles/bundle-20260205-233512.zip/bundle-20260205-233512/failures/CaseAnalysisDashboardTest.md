# Failure Brief: CaseAnalysisDashboardTest

**Component:** `focused:CaseAnalysisDashboardTest`
**Generated:** 2026-02-05T23:32:48+00:00
**Consecutive Failures:** 3

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh CaseAnalysisDashboardTest
```

---

## Failing Tests

- Tests\Feature\Livewire\CaseAnalysisDashboardTest > it

---

## Error Messages

```
  Failed asserting that two strings are equal.
  Failed asserting that two strings are equal.
  Failed asserting that two strings are equal.
  Failed asserting that exception of type "Symfony\Component\HttpKernel\Exception\HttpException" is thrown.
  Failed asserting that exception of type "Illuminate\View\ViewException" matches expected exception "Illuminate\Auth\Access\AuthorizationException". Message was: "SQLSTATE[42P01]: Undefined table: 7 ERROR:  relation "case_user" does not exist
```

---

## Stack Frames

```
/home/user/ai-legal-war-machine/app/Livewire/CaseAnalysisDashboard.php:45
/home/user/ai-legal-war-machine/app/Policies/LegalCasePolicy.php:22
/home/user/ai-legal-war-machine/storage/framework/views/d7de36a8b2692de70bab3211949ee568.php:7
/home/user/ai-legal-war-machine/tests/Feature/Livewire/CaseAnalysisDashboardTest.php:596
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:410
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:467
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:501
```

---

## Suspected Files

- `app/Livewire/CaseAnalysisDashboard.php`
- `app/Policies/LegalCasePolicy.php`
- `tests/Feature/Livewire/CaseAnalysisDashboardTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh CaseAnalysisDashboardTest`
2. **View full log:** `less test-logs/CaseAnalysisDashboardTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component CaseAnalysisDashboardTest`

