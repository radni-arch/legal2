# Support Bundle: bundle-20260205-233610

**Generated:** 2026-02-05T23:36:13+00:00
**Reason:** Consecutive failures threshold exceeded: focused:CaseAnalysisDashboardTest
**Branch:** claude/execute-document-analysis-a4asm
**Commit:** b420a89

## Contents

| Directory | Description |
|-----------|-------------|
| `logs/` | Setup logs, iteration logs |
| `metrics/` | JSONL metrics, last run metadata |
| `queue/` | TDD queue snapshot and summary |
| `session/` | Session state and notes |
| `failures/` | Failure briefs and RCA drafts |
| `matrix/` | Matrix check output |
| `env/` | Environment info (PHP, Node, Git) |

## Files

```
MANIFEST.md
alert-thresholds.json
context-budget.json
env/composer-packages.txt
env/git-branches.txt
env/git-log.txt
env/git-status.txt
env/node-version.txt
env/php-version.txt
env/system-info.txt
failures/AgentCypherQuerySafetyTest.md
failures/AgentVectorMemoryTest.md
failures/ApiKeyManageCommandTest.md
failures/ApiKeyRotatorServiceTest.md
failures/ApiKeyRotatorTest.md
failures/ApiKeyValidateCommandTest.md
failures/ArticleExtractorTest.md
failures/BatchCypherBuilderTest.md
failures/BatchOperationsBenchmarkTest.md
failures/BreadcrumbServiceTest.md
failures/CaseAnalysisDashboardTest.md
failures/CaseDecisionEvents.md
failures/CaseDecisionEventsTest.md
failures/CaseDecisionMatchingService.md
failures/CaseDecisionMatchingServiceTest.md
failures/CircuitBreakerIntegrationTest.md
failures/CleanOrphanedTextractNodesTest.md
failures/CollaborationDashboardTest.md
failures/ContextAnalyzerTest.md
failures/ContradictionRadarServiceTest.md
failures/CourtCaseDecisionMatch.md
failures/CourtCaseDecisionMatchTest.md
failures/CourtDecisionOutcomeColumnsTest.md
failures/CourtDecisionTagsUnicodeTest.md
failures/DateEventExtractorTest.md
failures/DateEventGraphSyncServiceTest.md
failures/DecisionGraphSyncServiceTest.md
failures/EkomApiClientTest.md
failures/EkomApiTest.md
failures/EkomDashboardTest.md
failures/EkomPredmetiListTest.md
failures/EkomPredmetiListTest__test_toggle_dnd_handles_service_error.md
failures/EkomSyncAllJobTest.md
failures/EnhancedGraphSyncJobTest.md
failures/EpredmetWidget.md
failures/EpredmetWidgetBatchFetchTest.md
failures/EpredmetWidgetTest.md
failures/EvidenceExtractorTest.md
failures/ExtractTablesFromTextractJobTest.md
failures/FactExtractionServiceTest.md
failures/FeedbackDashboardTest.md
failures/FetchCourtCasesJob.md
failures/FetchPpPrzCasesIntegrationTest.md
failures/ForceGraphControllerTest.md
failures/GraphConnectionExceptionTest.md
failures/GraphConsistencyCheckCommandTest.md
failures/GraphDataIntegrityServiceTest.md
failures/GraphDatabaseHealthTest.md
failures/GraphDatabaseServiceLoggingTest.md
failures/GraphDatabaseServiceTest.md
failures/GraphExceptionHierarchyTest.md
failures/GraphHealthCheckTest.md
failures/GraphInputSanitizerTest.md
failures/GraphSchemaApplyCommandTest.md
failures/GraphSyncExceptionTest.md
failures/GraphViewerErrorStatesTest.md
failures/GraphViewerInputValidationTest.md
failures/GraphViewerTest.md
failures/GraphViewerXssProtectionTest.md
failures/IllegalSearchDetectorTest.md
failures/IngestedLawsManagerTest.md
failures/LaravelLogViewerTest.md
failures/LawVectorStoreServiceTest.md
failures/LegalArgumentExtractorTest.md
failures/LegalArgumentGraphSyncServiceTest.md
failures/LegalConceptExtractorTest.md
failures/LegalDefinitionExtractorTest.md
failures/LegalDefinitionGraphSyncServiceTest.md
failures/LegalPlaygroundTest.md
failures/LegalPrincipleGraphSyncServiceTest.md
failures/LegalPrincipleGraphSyncServiceTest__it_reuses_existing_principle_node_for_same_pattern.md
failures/LegalTopicExtractorTest.md
failures/LlmBrainPanelErrorSanitizationTest.md
failures/LlmBrainPanelValidationTest.md
failures/LlmBrainPerformanceTest.md
failures/LogViewerServiceTest.md
failures/MatchCaseDecisionsCommandTest.md
failures/MatchCaseToDecisionJobTest.md
failures/MatchingResultTest.md
failures/OpenAIVectorManagerTest.md
failures/ProcessTextractJobTest.md
failures/ReconcileUnmatchedCasesJobTest.md
failures/ReconstructPdfV2Test.md
failures/RegenerateTextractEmbeddingsTest.md
failures/ReprocessTextractJobTest.md
failures/SuppressionMotionGeneratorTest.md
failures/SyncTextractToGraphTest.md
failures/TextractGraphSyncServiceTest.md
failures/TextractJobPolicyTest.md
failures/TextractServiceTest.md
failures/TopicAnalyzerTest.md
failures/TopicFrameworkIntegrationTest.md
failures/UnifiedSearchServiceFullTextFallbackTest.md
failures/UnifiedSearchTest.md
failures/UnmatchedCasesReportCommandTest.md
failures/WaitAndFetchStepTest.md
failures/rca-latest.md
flaky-tests.json
logs/autoloop-summary.json
logs/iterations.jsonl
logs/setup-all-hook.log
logs/setup-status.json
matrix/matrix-output.txt
metrics/.last-run.json
metrics/autoloop.jsonl
queue/queue-summary.txt
queue/tdd-test-queue.json
session/session-state.md
```

## Quick Analysis

### Queue Status
```
done: 58
todo: 534
```

### Recent Commits
```
b420a89 chore: update session logs
6a5b06b chore: update session logs
baa71d0 feat: implement code review suggestions (SUGGESTION-7,8)
0a37c06 chore: update session logs
e7d6305 fix: address code review findings (CRITICAL-1,3 + IMPORTANT-4)
```
