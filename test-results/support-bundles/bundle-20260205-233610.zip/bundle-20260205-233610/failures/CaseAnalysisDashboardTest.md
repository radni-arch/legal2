# Failure Brief: CaseAnalysisDashboardTest

**Component:** `focused:CaseAnalysisDashboardTest`
**Generated:** 2026-02-05T23:35:16+00:00
**Consecutive Failures:** 4

---

## Rerun Command

```bash
./scripts/run-focused-tests.sh CaseAnalysisDashboardTest
```

---

## Failing Tests



---

## Error Messages

```

```

---

## Stack Frames

```
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:537
tests/Feature/Livewire/CaseAnalysisDashboardTest.php:566
```

---

## Suspected Files

- `tests/Feature/Livewire/CaseAnalysisDashboardTest.php`
- `tests/Unit/Contracts/GraphLinkerContractTest.php`
- `tests/Unit/Contracts/GraphSyncServiceContractTest.php`

---

## Quick Actions

1. **Rerun test:** `./scripts/run-focused-tests.sh CaseAnalysisDashboardTest`
2. **View full log:** `less test-logs/CaseAnalysisDashboardTest-results.txt`
3. **Check metrics:** `php scripts/metrics-summary.php --component CaseAnalysisDashboardTest`

